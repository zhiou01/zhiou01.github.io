<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SoftwareSettings extends Model
{
    //
}
