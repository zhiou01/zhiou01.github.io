<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wp extends Model
{
    //
}
