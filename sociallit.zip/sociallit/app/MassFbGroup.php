<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MassFbGroup extends Model
{
    
}
