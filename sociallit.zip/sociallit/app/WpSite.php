<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WpSite extends Model
{
    //
}
