<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class campaign extends Model
{
    //
}
