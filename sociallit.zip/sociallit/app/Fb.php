<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fb extends Model
{
    //
}
