<?php $__env->startSection('title','Logs'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div id="slog"></div>
        <div class="content-wrapper">
            <section class="content">
                <div class="box no-border">
                    <div class="box-header with-border">
                        <h3 class="box-title">All scheduled data <label
                                    class="badge"><?php echo e(\App\OptLog::all()->count()); ?></label></h3>
                        <p>
                            <button class="btn btn-danger btn-xs" id="delall">Delete all logs</button>
                        </p>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                            <table id="mytable" class="table no-margin">
                                <thead>
                                <tr>
                                    <th>Post ID</th>
                                    <th>Status</th>
                                    <th>Type</th>
                                    <th>Posted on</th>
                                    <th>Time</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>


                                        <td><a><?php echo e($data->postId); ?></a></td>
                                        <td><?php if($data->status=='success'): ?><label
                                                    class="label label-success">Success</label><?php else: ?> <label
                                                    class="label label-danger">Failed</label><?php endif; ?></td>
                                        <td><?php echo e($data->type); ?></td>
                                        <td><?php echo e($data->from); ?></td>
                                        <td><?php echo e($data->created_at); ?></td>
                                        <td>
                                            <div data-id="<?php echo e($data->id); ?>" class="logdel"><a class="label label-danger"><i
                                                            class="fa fa-times"></i> Delete</a></div>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.box-body -->

                    <!-- /.box-footer -->
                </div>

            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <script src="<?php echo e(url('/opt/sweetalert.min.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/opt/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>