<?php $__env->startSection('title','Auto Repin'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div class="content-wrapper">
            <section class="content">

                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-6">
                            <p><b>Search For</b></p>
                            <input placeholder="Food,Cat..." type="text" class="form-control" id="search"><br>
                            <p><b>Select Board</b></p>
                            <select id="board" class="form-control">
                                <?php $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($board['id']); ?>"><?php echo e($board['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <br>
                            <button class="btn btn-success btn-xs" data-toggle="modal" data-target="#modal-default"
                            >Create New Board
                            </button>

                            <br>
                            <br>
                            <button id="comment" class="btn btn-block btn-success"><i class="fa fa-map-pin"></i> Run
                                Auto Repin
                            </button>
                            <br>
                            <p id="msg"></p>

                        </div>
                    </div>
                </div>

                <div class="modal fade" id="modal-default">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Default Modal</h4>
                            </div>
                            <div class="modal-body">
                                <label>Board Name</label>
                                <input type="text" class="form-control" id="board_name">
                                <label>Description</label>
                                <input type="text" class="form-control" id="board_description">

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close
                                </button>
                                <button id="create_board" type="button" class="btn btn-primary"><i
                                            class="fa fa-plus"></i> Create Board
                                </button>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>

            </section>
        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        $("#comment").click(function () {
            $('#msg').html("Please wait .It will take time ....");
            $.ajax({
                url: '<?php echo e(url('pinterest/auto/repin')); ?>',
                type: 'POST',
                data: {
                    'boardId': $('#board').val(),
                    'search': $('#search').val()
                },
                success: function (data) {
                    $('#msg').html(data);
                },
                error: function (data) {
                    alert("Something went wrong");
                    console.log(data.responseText);
                }
            })
        });

        $('#create_board').click(function () {
            var boardName = $("#board_name").val();
            var boardDescription = $('#board_description').val();
            $.ajax({
                type: 'POST',
                url: '<?php echo e(url('/pinterest/create/board')); ?>',
                data: {
                    'boardName': boardName,
                    'boardDescription': boardDescription
                },
                success: function (data) {
                    if (data == "success") {
                        alert("Created !");
                        location.reload();
                    } else {
                        alert(data);
                    }
                },
                error: function (data) {
                    alert("Something went wrong");
                    console.log(data.responseText);
                }
            });
        })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>