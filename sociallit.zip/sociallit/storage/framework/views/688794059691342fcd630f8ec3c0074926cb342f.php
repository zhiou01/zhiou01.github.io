<?php $__env->startSection('title','Facebook'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper" xmlns="http://www.w3.org/1999/html">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="content-wrapper">
            <section class="content">

                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Conversations of <?php echo e($data['name']); ?> </h3>
                    </div>
                    <div class="box-body">
                        <table id="mytable" class="table table-bordered table-striped" cellspacing="0" width="100%">
                            <thead>
                            <tr>
                                <th>Participants</th>
                                <th>Message Counts</th>
                                <th>Action</th>

                            </tr>
                            </thead>

                            <tbody>
                            <?php if(isset($data['conversations'])): ?>
                                <?php $__currentLoopData = $data['conversations']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php $__currentLoopData = $con['participants']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $par): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a target="_blank"
                                                   href="http://facebook.com/<?php echo e($par['id']); ?>"><?php echo e($par['name']); ?> </a> ,
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </td>
                                        <td><?php echo e($con['message_count']); ?></td>
                                        <td><a class="btn btn-success" target="_blank"
                                               href="<?php echo e(url('/conversations/')); ?>/<?php echo e($data['id']); ?>/<?php echo e($con['id']); ?>"><i class="fa fa-comments-o"></i> Start
                                                Conversation</a></td>


                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>

                            <tfoot>
                            <tr>
                                <th>Participants</th>
                                <th>Message Counts</th>
                                <th>Action</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>


            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>