


<ul class="timeline">
    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $src): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($src != ""): ?>
            <li>
                <i class="fa fa-image bg-green"></i>

                <div class="timeline-item">
                    <div class="timeline-body">
                        <img src="<?php echo e($src); ?>">
                    </div>
                    <div class="timeline-footer">
                        <a class="btn btn-success btn-xs" href="<?php echo e($src); ?>" target="_blank"><i class="fa fa-download"></i> Image Download Link</a>
                        <a class="btn btn-default bg-blue-active btn-xs" target="_blank" href="http://www.facebook.com/sharer.php?u=<?php echo e($src); ?>"><i class="fa fa-facebook"></i> Post to
                            Facebook</a>

                        <a class="btn btn-default bg-red btn-xs" target="_blank" href="https://pinterest.com/pin/create/button/?url=&media=<?php echo e($src); ?>&description="><i class="fa fa-pinterest"></i> Share to Pinterest</a>


                    </div>
                </div>
            </li>
        <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <li>
            <i class="fa fa-clock-o bg-gray"></i>
        </li>
</ul>

