<?php $__currentLoopData = $datas->ranked_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="<?php echo e($data->id); ?>" class="row">
        <div class="col-md-6">
            <!-- Box Comment -->
            <div class="box box-widget">
                <div class="box-header with-border">
                    <div class="user-block">
                        <img class="img-circle" src="<?php echo e($data->user->profile_pic_url); ?>" alt="User Image">
                        <span class="username"><a href="#"><?php echo e($data->user->full_name); ?></a></span>
                        
                    </div>
                    <!-- /.user-block -->
                    <div class="box-tools">

                        <a target="_blank" href="<?php echo e(url('/instagram/info')."/".$data->id); ?>" class="btn btn-xs btn-default">View Details</a>
                        <button type="button" class="btn btn-box-tool" data-toggle="tooltip" title=""
                                data-original-title="Instagram Post">
                            <i class="fa fa-circle-o"></i></button>
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i
                                    class="fa fa-minus"></i>
                        </button>

                    </div>
                    <!-- /.box-tools -->
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <?php if($data->media_type == 1): ?>
                        <img class="img-responsive pad"
                             src="<?php echo e($data->image_versions2->candidates[0]->url); ?>" alt="Photo">
                    <?php elseif($data->media_type == 2): ?>
                        <video width="400" controls>
                            <source src="<?php echo e($data->video_versions[2]->url); ?>" type="video/mp4">

                            Your browser does not support HTML5 video.
                        </video>
                    <?php endif; ?>
                    <?php if($data->caption != ""): ?>
                        <p><?php echo e($data->caption->text); ?></p>
                    <?php endif; ?>
                    


                    
                        
                                    
                                    
                    
                    <br>
                    <?php if($data->media_type == 2): ?>


                        <a target="_blank" href="<?php echo e($data->video_versions[0]->url); ?>"
                           class="label label-primary"><i
                                    class="fa fa-download"></i> <?php echo e($data->video_versions[0]->width." X ".$data->video_versions[0]->height); ?>

                            Download video <i class="fa fa-video-camera"></i>
                        </a>

                    <?php endif; ?>

                    <br>
                    <div class="pull-left"> Top Likers</div>
                    <br>


                    <span class="pull-right text-muted"><?php echo e($data->like_count); ?>

                        likes - <?php echo e($data->comment_count); ?> comments</span>
                </div>
                <!-- /.box-body -->
                <div class="box-footer box-comments">
                    <?php $__currentLoopData = $data->preview_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="box-comment">
                            <!-- User image -->
                            <img class="img-circle img-sm" src="<?php echo e($comment->user->profile_pic_url); ?>"
                                 alt="User Image">

                            <div class="comment-text">
                      <span class="username">
                       <a href="https://instagram.com/<?php echo e($comment->user->username); ?>" target="_blank"><?php echo e($comment->user->full_name); ?></a>
                          <span class="text-muted pull-right"><div class="time">
                                  
                              </div> </span>

                      </span><!-- /.username -->
                                <?php echo e($comment->text); ?>

                            </div>
                            <!-- /.comment-text -->
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <!-- /.box-comment -->

                    <!-- /.box-comment -->
                </div>
                <!-- /.box-footer -->


            </div>
            <!-- /.box -->
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>