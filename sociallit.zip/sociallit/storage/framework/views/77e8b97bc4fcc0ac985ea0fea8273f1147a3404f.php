<?php $__env->startSection('title','Facebook'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper" xmlns="http://www.w3.org/1999/html">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div id="chat"></div>
        <div class="content-wrapper">
            <section class="content">
                <div class="col-md-6">
                    <!-- DIRECT CHAT -->
                    <div class="box box-success direct-chat direct-chat-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">Direct Chat</h3>

                            <div class="box-tools pull-right">
                                <span data-toggle="tooltip" title="<?php echo e($response['message_count']); ?> Messages"
                                      class="badge bg-red-gradient"><?php echo e($response['message_count']); ?></span>
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i
                                            class="fa fa-minus"></i>
                                </button>
                                <button type="button" class="btn btn-box-tool" data-toggle="tooltip" title="Contacts"
                                        data-widget="chat-pane-toggle">
                                    <i class="fa fa-comments"></i></button>

                                </button>
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <!-- Conversations are loaded here -->
                            <div id="chatBox" class="direct-chat-messages">
                                <!-- Message. Default to the left -->
                                <?php $__currentLoopData = array_reverse($response['messages']['data']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="direct-chat-msg <?php if($data['from']['id'] == $me): ?>right <?php endif; ?>">
                                        <div class="direct-chat-info clearfix">
                                            <span class="direct-chat-name pull-<?php if($data['from']['id'] == $me): ?>right <?php else: ?> left <?php endif; ?>"><?php echo e($data['from']['name']); ?></span>
                                            <span class="direct-chat-timestamp pull-<?php if($data['from']['id'] == $me): ?>left <?php else: ?> right <?php endif; ?>"><?php echo e(\App\Http\Controllers\Prappo::date($data['created_time'])); ?></span>
                                        </div>
                                        <!-- /.direct-chat-info -->
                                        <?php $__currentLoopData = $response['participants']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $par): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        
                                        <div class="direct-chat-text">
                                            <?php echo e($data['message']); ?>

                                        </div>
                                        <!-- /.direct-chat-text -->
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <!--/.direct-chat-messages-->

                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">

                            <div class="input-group">
                                <input type="text" id="message" name="message" placeholder="Type Message ..."
                                       class="form-control">
                                <span class="input-group-btn">
                            <button type="button" id="send" class="btn btn-success btn-flat">Send</button>
                          </span>
                            </div>

                        </div>
                        <!-- /.box-footer-->
                    </div>
                    <!--/.direct-chat -->
                </div>

            </section>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        var chatbox = $('#chatBox');
        chatbox.scrollTop(chatbox[0].scrollHeight);

        if (document.getElementById('chat')) {
            var chatbox = $('#chatBox');
            $('#send').click(function () {
                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(url('/chat')); ?>',
                    data: {
                        'pageId': '<?php echo e($me); ?>',
                        'conId': '<?php echo e($response['id']); ?>',
                        'message': $('#message').val()
                    },
                    success: function (data) {
                        $('#msg').html(data);
                    }
                });
                $('#message').val('');
                auto_load();
                chatbox.scrollTop(chatbox[0].scrollHeight);
            });

            $('#message').bind("enterKey", function (e) {
                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(url('/chat')); ?>',
                    data: {
                        'pageId': '<?php echo e($me); ?>',
                        'conId': '<?php echo e($response['id']); ?>',
                        'message': $('#message').val()
                    },
                    success: function (data) {
                        $('#msg').html(data);
                    }
                });
                $('#message').val('');
                auto_load();
                chatbox.scrollTop(chatbox[0].scrollHeight);
            });
            $('#message').keyup(function (e) {
                if (e.keyCode == 13) {
                    $(this).trigger("enterKey");
                }
            });
            function auto_load() {

                $.ajax({
                    type: "GET",
                    url: '<?php echo e(url('/ajaxchat/')); ?>/<?php echo e($me); ?>/<?php echo e($response['id']); ?>',
                    success: function (data) {
                        $('#chatBox').html(data);

                    }

                });

            }

            setInterval(auto_load, 2000);

        }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>