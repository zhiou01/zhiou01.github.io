<?php $__env->startSection('title','Retweet'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="content-wrapper">
            <section class="content">
                <div align="center" class="row">
                    <button id="retweet" class="btn btn-success btn-lg"><i class="fa fa-retweet"></i> Retweet all tweet
                        where you are mentioned
                    </button>

                </div>
                <div style="padding-left:10px" class="row">
                    <div class="panel-body">
                        <div id="result"></div>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('#retweet').click(function () {
            $(this).html("Please wait .....");
            $.ajax({
                type: 'POST',
                url: '<?php echo e(url('/twitter/autoretweet')); ?>',
                data: {},
                success: function (data) {
                    $('#result').html(data);
                    $('#retweet').html('<i class="fa fa-retweet"></i> Retweet all tweet where you are mentioned');
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>