<?php $__env->startSection('title','Admin Options | SocialLit'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div id="settingspage"></div>

        <div class="content-wrapper">
            <section class="content">
                <div class="row">
                    <div class="bor no-border">
                        <div class="box-body">
                            <div id="update_notification" style="display:none;" class="alert alert-info">
                                <button type="button" style="margin-left: 20px" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="box no-border">
                        <div class="box-header with-border" align="center">
                            <h3 class="box-title"><i class="fa fa-clock-o"></i> Schedule settings ( Cron Job )</h3>
                        </div>

                        <div class="box-body">
                            <h4>Add this command to crontab ( Recommended )</h4>
                            <div class="well">
                                <code>
                                    * * * * * php <?php echo e(base_path('artisan schedule:run >> /dev/null 2>&1')); ?>

                                </code>
                            </div>
                            <h4>If above command doesn't work for your server then add this</h4>

                            <div class="well">
                                <code>
                                    * * * * * curl <?php echo e(url('/schedule/fire')); ?>

                                </code>
                            </div>
                        </div>
                    </div>

                </div>


            </section>
        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .row {
            margin: 5px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>