<?php $__env->startSection('title','My Pins'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div class="content-wrapper">
            <section class="content">
                <div class="row">
                    <div class="col-md-12">

                        <div class="col-md-4">
                            <!-- Widget: user widget style 1 -->
                            <div class="box box-widget widget-user">
                                <!-- Add the bg color to the header using any of the bg-* classes -->
                                <div class="widget-user-header bg-red-gradient">
                                    <h3 class="widget-user-username"><?php echo e($pins['1']['pinner']['full_name']); ?></h3>
                                    <h5 class="widget-user-desc"><?php echo e($pins['1']['pinner']['username']); ?></h5>
                                </div>
                                <div class="widget-user-image">
                                    <img class="img-circle" src="<?php echo e($pins['1']['pinner']['image_large_url']); ?>"
                                         alt="User Avatar">
                                </div>
                                <div class="box-footer">
                                    <div class="row">
                                        <div class="col-sm-6 border-right">
                                            <div class="description-block">
                                                <h5 class="description-header"><?php echo e($pins['1']['pinner']['board_count']); ?></h5>
                                                <span class="description-text">BOARDS</span>
                                            </div>
                                            <!-- /.description-block -->
                                        </div>
                                        <!-- /.col -->
                                        <div class="col-sm-6 border-right">
                                            <div class="description-block">
                                                <h5 class="description-header"><?php echo e($pins['1']['pinner']['follower_count']); ?></h5>
                                                <span class="description-text">FOLLOWERS</span>
                                            </div>
                                            <!-- /.description-block -->
                                        </div>
                                        <!-- /.col -->

                                        <!-- /.col -->
                                    </div>
                                    <!-- /.row -->
                                </div>
                            </div>
                            <!-- /.widget-user -->
                        </div>
                        <div class="col-md-8">
                            <div class="col-md-12">
                                <!-- The time line -->
                                <ul class="timeline">
                                    <!-- timeline time label -->
                                    <li class="time-label">
                  <span class="bg-red">
                  My Wall
                  </span>
                                    </li>
                                    <?php $__currentLoopData = $pins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <i class="fa fa-pinterest bg-red"></i>

                                            <div class="timeline-item">
                                            <span class="time"><i
                                                        class="fa fa-clock-o"></i> <?php echo e($pin['created_at']); ?></span>

                                                <h3 class="timeline-header"><a href="#"><?php echo e($pin['board']['name']); ?></a>
                                                </h3>

                                                <div class="timeline-body">
                                                    <?php $__currentLoopData = $pin['board']['images']['170x']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <img src="<?php echo e($image['url']); ?>" alt="..." class="margin">
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <li>

                                        <i class="fa fa-circle-o bg-gray"></i>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>


            </section>
        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>