<?php $__env->startSection('title','Twitter'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="content-wrapper">
            <section class="content">
                <div class="row">

                    <div class="col-md-12">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#activity" data-toggle="tab">Home</a></li>
                                <li><a href="#replies" data-toggle="tab">Tweets & replies</a></li>
                                <li><a href="#me" data-toggle="tab">Tweets</a></li>


                            </ul>
                            <div class="tab-content">
                                <div class="active tab-pane" id="activity">
                                    <!-- Post -->
                                    <?php $__currentLoopData = $tw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t=>$fields): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="post">
                                            <div class="user-block">
                                                <img class="img-circle img-bordered-sm"
                                                     src="<?php echo e($fields->user->profile_image_url); ?>" alt="user image">
                                                <span class='username'>
                          <a target="_blank"
                             href="http://twitter.com/<?php echo e($fields->user->screen_name); ?>"><?php echo e($fields->user->name); ?></a>

                                                    <div class="btn-group pull-right" role="group" aria-label="...">
                                                    <a data-user="<?php echo e($fields->user->screen_name); ?>"
                                                       class='optmsg btn-xs btn btn-success'><i
                                                                class='fa fa-envelope'></i> Send Message</a>
                            <a data-id="<?php echo e($fields->id); ?>" class='optretweet btn-xs btn btn-primary'><i
                                        class='fa fa-retweet'></i> Retweet</a>
                                                        <a data-id="<?php echo e($fields->id); ?>"
                                                           data-user="<?php echo e($fields->user->screen_name); ?>"
                                                           class='optreply btn-xs btn btn-warning'><i
                                                                    class='fa fa-reply'></i> Reply</a>
                                                        </div>
                                                    <a target="_top"
                                                       onclick="window.open('https://plus.google.com/share?url=https://twitter.com/<?php echo e($fields->user->screen_name); ?>/status/<?php echo e($fields->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                       href="https://plus.google.com/share?url=https://twitter.com/<?php echo e($fields->user->screen_name); ?>/status/<?php echo e($fields->id); ?>"
                                                       class='pull-right btn-box-tool'><i class='fa fa-google-plus'></i></a>
                                                <a target="_top"
                                                   onclick="window.open('https://www.linkedin.com/cws/share?url=https://twitter.com/<?php echo e($fields->user->screen_name); ?>/status/<?php echo e($fields->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                   href="https://www.linkedin.com/cws/share?url=https://twitter.com/<?php echo e($fields->user->screen_name); ?>/status/<?php echo e($fields->id); ?>"
                                                   class='pull-right btn-box-tool'><i class='fa fa-linkedin'></i></a>
                                                <a target="_top"
                                                   onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=https://twitter.com/<?php echo e($fields->user->screen_name); ?>/status/<?php echo e($fields->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                   href="https://www.facebook.com/sharer/sharer.php?u=https://twitter.com/<?php echo e($fields->user->screen_name); ?>/status/<?php echo e($fields->id); ?>"
                                                   class='pull-right btn-box-tool'><i class='fa fa-facebook'></i></a>
                                                <a target="_top"
                                                   onclick="window.open('http://www.reddit.com/submit?url=https://twitter.com/<?php echo e($fields->user->screen_name); ?>/status/<?php echo e($fields->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                   href="http://www.reddit.com/submit?url=https://twitter.com/<?php echo e($fields->user->screen_name); ?>/status/<?php echo e($fields->id); ?>"
                                                   class='pull-right btn-box-tool'><i class='fa fa-reddit'></i></a>
                                                <a target="_top"
                                                   onclick="window.open('http://pinterest.com/pin/create/link/?url=https://twitter.com/<?php echo e($fields->user->screen_name); ?>/status/<?php echo e($fields->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                   href="http://pinterest.com/pin/create/link/?url=https://twitter.com/<?php echo e($fields->user->screen_name); ?>/status/<?php echo e($fields->id); ?>"
                                                   class='pull-right btn-box-tool'><i class='fa fa-pinterest-p'></i></a>
                        </span>

                                                <span class='description'><?php echo e($fields->user->created_at); ?></span>
                                            </div><!-- /.user-block -->
                                            <p>
                                                <?php echo e($fields->text); ?>

                                                <br>

                                            </p>
                                            <div class="row" style="padding-left: 10px"><img
                                                        src="<?php echo e(url('/images/optimus/social/twlove.gif')); ?>"> <?php echo e($fields->favorite_count); ?>

                                                <img
                                                        style="margin-left: 10px" height="20" width="20"
                                                        src="<?php echo e(url('/images/optimus/social/retweet.png')); ?>"> <?php echo e($fields->retweet_count); ?>

                                            </div>

                                            &nbsp;Mentions :
                                            <?php $__currentLoopData = $fields->entities->user_mentions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mNo => $mentions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <a href="http://twitter.com/<?php echo e($mentions->screen_name); ?>" target="_blank"><span
                                                            class="badge bg-aqua"><?php echo e($mentions->name); ?></span></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div><!-- /.post -->



                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- Post -->


                                </div><!-- /.tab-pane -->
                                


                                

                                <div class="tab-pane" id="replies">
                                    <?php $__currentLoopData = $twRep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="box box-widget widget-user-2">
                                            <!-- Add the bg color to the header using any of the bg-* classes -->
                                            <div class="widget-user-header bg-aqua-active">
                                                <div class="widget-user-image">
                                                    <img class="img-circle" src="<?php echo e($obj->user->profile_image_url); ?>"
                                                         alt="User Avatar">
                                                </div>
                                                <!-- /.widget-user-image -->
                                                <h3 class="widget-user-username"><?php echo e($obj->user->name); ?></h3>
                                                <h5 class="widget-user-desc"> <?php echo e($obj->user->description); ?></h5>
                                            </div>
                                            <div class="box-footer no-padding">
                                                <ul class="nav nav-stacked">
                                                    <li>

                                                        <div class="row">
                                                            <div class="col-sm-3 border-right">
                                                                <div class="description-block">
                                                                    <h5 class="description-header"><?php echo e($obj->user->followers_count); ?></h5>
                                                                    <span class="description-text">FOLLOWERS</span>
                                                                </div>
                                                                <!-- /.description-block -->
                                                            </div>
                                                            <!-- /.col -->
                                                            <div class="col-sm-2 border-right">
                                                                <div class="description-block">
                                                                    <h5 class="description-header"><?php echo e($obj->user->friends_count); ?></h5>
                                                                    <span class="description-text">FRIENDS</span>
                                                                </div>
                                                                <!-- /.description-block -->
                                                            </div>
                                                            <!-- /.col -->

                                                            <div class="row">
                                                                <div class="col-sm-2 border-right">
                                                                    <div class="description-block">
                                                                        <h5 class="description-header"><?php echo e($obj->user->favourites_count); ?></h5>
                                                                        <span class="description-text">FAVOURITES</span>
                                                                    </div>
                                                                    <!-- /.description-block -->
                                                                </div>
                                                                <!-- /.col -->
                                                                <div class="col-sm-2 border-right">
                                                                    <div class="description-block">
                                                                        <h5 class="description-header"><?php echo e($obj->user->statuses_count); ?></h5>
                                                                        <span class="description-text">STATUSES</span>
                                                                    </div>
                                                                    <!-- /.description-block -->
                                                                </div>


                                                                <div class="col-sm-2 border-right">
                                                                    <div class="description-block">
                                                                        <h5 class="description-header"><?php echo e($obj->user->listed_count); ?></h5>
                                                                        <span class="description-text">LISTED</span>
                                                                    </div>
                                                                    <!-- /.description-block -->
                                                                </div>


                                                            </div>
                                                        </div>

                                                    </li>
                                                    <li>
                                                        <h3><p><?php echo e($obj->text); ?></p></h3>
                                                    </li>

                                                    <li>
                                                        <div class="row">
                                                            <img style="padding-left: 10px"
                                                                 src="<?php echo e(url('/images/optimus/social/twlove.gif')); ?>"> <?php echo e($obj->favorite_count); ?>

                                                            <img
                                                                    style="margin-left: 10px" height="20" width="20"
                                                                    src="<?php echo e(url('/images/optimus/social/retweet.png')); ?>"> <?php echo e($obj->retweet_count); ?>


                                                            &nbsp; Mentions :
                                                            <?php $__currentLoopData = $obj->entities->user_mentions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mNo => $mentions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                <a href="http://twitter.com/<?php echo e($mentions->screen_name); ?>"
                                                                   target="_blank"><span
                                                                            class="badge bg-aqua"><?php echo e($mentions->name); ?></span></a>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </div>
                                                        <div class="row" style="padding-left: 10px">
                                                            <button data-user="<?php echo e($obj->user->screen_name); ?>"
                                                                    class="btn btn-xs optmsg btn-success"><i
                                                                        class="fa fa-envelope"></i> Send message
                                                                to <?php echo e($obj->user->name); ?></button>
                                                            <button data-id="<?php echo e($obj->id); ?>"
                                                                    class="btn btn-xs optretweet btn-primary"><i
                                                                        class="fa fa-retweet"></i> Retweet
                                                            </button>
                                                            <button data-id="<?php echo e($obj->id); ?>"
                                                                    data-user="<?php echo e($obj->user->screen_name); ?>"
                                                                    class="btn btn-xs optreply btn-warning"><i
                                                                        class="fa fa-reply"></i> Reply
                                                            </button>
                                                        </div>
                                                        <a target="_top"
                                                           onclick="window.open('https://plus.google.com/share?url=https://twitter.com/<?php echo e($obj->user->screen_name); ?>/status/<?php echo e($obj->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                           href="https://plus.google.com/share?url=https://twitter.com/<?php echo e($obj->user->screen_name); ?>/status/<?php echo e($obj->id); ?>"
                                                           class='pull-right btn-box-tool'><i
                                                                    class='fa fa-google-plus'></i></a>
                                                        <a target="_top"
                                                           onclick="window.open('https://www.linkedin.com/cws/share?url=https://twitter.com/<?php echo e($obj->user->screen_name); ?>/status/<?php echo e($obj->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                           href="https://www.linkedin.com/cws/share?url=https://twitter.com/<?php echo e($obj->user->screen_name); ?>/status/<?php echo e($obj->id); ?>"
                                                           class='pull-right btn-box-tool'><i
                                                                    class='fa fa-linkedin'></i></a>
                                                        <a target="_top"
                                                           onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=https://twitter.com/<?php echo e($obj->user->screen_name); ?>/status/<?php echo e($obj->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                           href="https://www.facebook.com/sharer/sharer.php?u=https://twitter.com/<?php echo e($obj->user->screen_name); ?>/status/<?php echo e($obj->id); ?>"
                                                           class='pull-right btn-box-tool'><i
                                                                    class='fa fa-facebook'></i></a>
                                                        <a target="_top"
                                                           onclick="window.open('http://www.reddit.com/submit?url=https://twitter.com/<?php echo e($obj->user->screen_name); ?>/status/<?php echo e($obj->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                           href="http://www.reddit.com/submit?url=https://twitter.com/<?php echo e($obj->user->screen_name); ?>/status/<?php echo e($obj->id); ?>"
                                                           class='pull-right btn-box-tool'><i
                                                                    class='fa fa-reddit-alien'></i></a>
                                                        <a target="_top"
                                                           onclick="window.open('http://pinterest.com/pin/create/link/?url=https://twitter.com/<?php echo e($obj->user->screen_name); ?>/status/<?php echo e($obj->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                           href="http://pinterest.com/pin/create/link/?url=https://twitter.com/<?php echo e($obj->user->screen_name); ?>/status/<?php echo e($obj->id); ?>"
                                                           class='pull-right btn-box-tool'><i
                                                                    class='fa fa-pinterest-p'></i></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                

                                <div class="tab-pane" id="me">
                                    <?php $__currentLoopData = $me; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t=>$f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="post">
                                            <div class="user-block">
                                                <img class="img-circle img-bordered-sm"
                                                     src="<?php echo e($f->user->profile_image_url); ?>" alt="user image">
                                                <span class='username'>
                          <a href="#"><?php echo e($f->user->name); ?></a>
                          <div data-id="<?php echo e($f->id); ?>" class="optimustwdel"><a class='pull-right btn-box-tool'><i
                                          class='fa fa-times'></i></a></div>
                                                    <a target="_top"
                                                       onclick="window.open('https://plus.google.com/share?url=https://twitter.com/<?php echo e($f->user->screen_name); ?>/status/<?php echo e($f->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                       href="https://plus.google.com/share?url=https://twitter.com/<?php echo e($f->user->screen_name); ?>/status/<?php echo e($f->id); ?>"
                                                       class='pull-right btn-box-tool'><i class='fa fa-google-plus'></i></a>
                                                        <a target="_top"
                                                           onclick="window.open('https://www.linkedin.com/cws/share?url=https://twitter.com/<?php echo e($f->user->screen_name); ?>/status/<?php echo e($f->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                           href="https://www.linkedin.com/cws/share?url=https://twitter.com/<?php echo e($f->user->screen_name); ?>/status/<?php echo e($f->id); ?>"
                                                           class='pull-right btn-box-tool'><i
                                                                    class='fa fa-linkedin'></i></a>
                                                        <a target="_top"
                                                           onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=https://twitter.com/<?php echo e($f->user->screen_name); ?>/status/<?php echo e($f->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                           href="https://www.facebook.com/sharer/sharer.php?u=https://twitter.com/<?php echo e($f->user->screen_name); ?>/status/<?php echo e($f->id); ?>"
                                                           class='pull-right btn-box-tool'><i
                                                                    class='fa fa-facebook'></i></a>
                                                        <a target="_top"
                                                           onclick="window.open('http://www.reddit.com/submit?url=https://twitter.com/<?php echo e($f->user->screen_name); ?>/status/<?php echo e($f->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                           href="http://www.reddit.com/submit?url=https://twitter.com/<?php echo e($f->user->screen_name); ?>/status/<?php echo e($f->id); ?>"
                                                           class='pull-right btn-box-tool'><i
                                                                    class='fa fa-reddit-square'></i></a>
                                                        <a target="_top"
                                                           onclick="window.open('http://pinterest.com/pin/create/link/?url=https://twitter.com/<?php echo e($f->user->screen_name); ?>/status/<?php echo e($f->id); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                           href="http://pinterest.com/pin/create/link/?url=https://twitter.com/<?php echo e($f->user->screen_name); ?>/status/<?php echo e($f->id); ?>"
                                                           class='pull-right btn-box-tool'><i
                                                                    class='fa fa-pinterest-p'></i></a>
                        </span>
                                                <span class='description'><?php echo e($f->user->created_at); ?></span>
                                            </div><!-- /.user-block -->
                                            <p>
                                                <?php echo e($f->text); ?>

                                                <br>

                                            </p>
                                            <div class="row" style="padding-left: 10px"><img
                                                        src="<?php echo e(url('/images/optimus/social/twlove.gif')); ?>"> <?php echo e($f->favorite_count); ?>

                                                <img
                                                        style="margin-left: 10px" height="20" width="20"
                                                        src="<?php echo e(url('/images/optimus/social/retweet.png')); ?>"> <?php echo e($f->retweet_count); ?>

                                            </div>

                                            &nbsp; Mentions :
                                            <?php $__currentLoopData = $f->entities->user_mentions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mNo => $mentions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <a href="http://twitter.com/<?php echo e($mentions->screen_name); ?>" target="_blank"><span
                                                            class="badge bg-aqua"><?php echo e($mentions->name); ?></span></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div><!-- /.post -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                            
                            <!-- /.tab-pane -->
                            </div><!-- /.tab-content -->
                        </div><!-- /.nav-tabs-custom -->
                    </div><!-- /.col -->
                </div><!-- /.row -->

            </section>
        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <script src="<?php echo e(url('/opt/sweetalert.min.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/opt/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $('.optretweet').click(function () {
            var id = $(this).attr('data-id');
            $.ajax({
                type: 'POST',
                url: '<?php echo e(url('/twitter/retweet')); ?>',
                data: {
                    'id': id
                },
                success: function (data) {
                    if (data == 'success') {
                        swal('Success', 'Retweeted ', 'success');
                    }
                    else {
                        swal('Error', data, 'error');
                    }
                }
            });
        });
        $('.optmsg').click(function () {
            var user = $(this).attr('data-user');

            swal({
                title: "Message",
                text: "Write Your message here:",
                type: "input",
                showCancelButton: true,
                closeOnConfirm: false,
                animation: "slide-from-top",
                inputPlaceholder: "Write something",
                showLoaderOnConfirm: true,
            }, function (inputValue) {
                if (inputValue === false) return false;
                if (inputValue === "") {
                    swal.showInputError("You need to write something!");
                    return false
                }
                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(url('/twitter/message')); ?>',
                    data: {
                        'username': user,
                        'text': inputValue
                    },
                    success: function (data) {
                        if (data == 'success') {
                            swal('Success', 'Message sent', 'success');
                        }
                        else {
                            swal('Error', data, 'error');
                        }
                    }
                });
            });

        });
        $('.optreply').click(function () {
            var user = $(this).attr('data-user');
            var id = $(this).attr('data-id');

            swal({
                title: "Reply",
                text: "Write Your reply here:",
                type: "input",
                showCancelButton: true,
                closeOnConfirm: false,
                animation: "slide-from-top",
                inputPlaceholder: "Write something",
                showLoaderOnConfirm: true,
            }, function (inputValue) {
                if (inputValue === false) return false;
                if (inputValue === "") {
                    swal.showInputError("You need to write something!");
                    return false
                }
                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(url('/twitter/reply')); ?>',
                    data: {
                        'username': user,
                        'text': inputValue,
                        'id': id
                    },
                    success: function (data) {
                        if (data == 'success') {
                            swal('Success', 'Message sent', 'success');
                        }
                        else {
                            swal('Error', data, 'error');
                        }
                    }
                });
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>