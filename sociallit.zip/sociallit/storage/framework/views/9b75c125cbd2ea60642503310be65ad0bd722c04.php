<?php $__env->startSection('title','Facebook Pages'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="content-wrapper">
            <section class="content">

                <div class="panel panel-success">
                    <div class="panel-heading">Select a page
                    </div>
                    <div class="panel-body">
                        <div class="list-group">

                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item"><a target="_blank"
                                                               href="<?php echo e(url('/campaign/page')); ?>/<?php echo e($page->pageId); ?>"><i class="fa fa-facebook-square"></i> <?php echo e($page->pageName); ?></a>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>

                    </div>
                </div>

            </section>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>