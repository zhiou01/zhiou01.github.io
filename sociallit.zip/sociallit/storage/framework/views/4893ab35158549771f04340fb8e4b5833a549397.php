<?php $__env->startSection('title','Wordpress'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div id="wppage"></div>
        <div class="content-wrapper">
            <section class="content">
                <div class="row">

                    <div class="col-md-12">
                        <div class="box">
                            <div class="box-body">
                                <?php $__currentLoopData = \App\WpSite::where('userId',Auth::user()->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3">
                                        <div class="info-box">
                                                <span class="info-box-icon bg-gray"><i
                                                            class="fa fa-wordpress"></i></span>

                                            <div class="info-box-content">

                                                <span class="info-box-number"><?php echo e($wp->name); ?></span>
                                                <div class="btn-group btn-block">
                                                    <button data-id="<?php echo e($wp->id); ?>"
                                                            class="btn delWp btn-xs btn-danger"><i
                                                                class="fa fa-trash"></i>
                                                        Delete
                                                    </button>
                                                    <a href="<?php echo e($wp->url); ?>" target="_blank"
                                                       class="btn btn-xs btn-primary"><i class="fa fa-link"></i>
                                                        Visit</a>
                                                </div>

                                                <a href="<?php echo e(url('/wordpress/site').'/'.$wp->id); ?>"
                                                   class="btn btn-xs btn-success btn-block">Manage</a>
                                            </div>
                                            <!-- /.info-box-content -->
                                        </div>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div><!-- /.nav-tabs-custom -->
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </section>
        </div>

        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <script src="<?php echo e(url('/opt/sweetalert.min.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/opt/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $('.btn-danger').click(function () {
            var id = $(this).attr('data-id');

            swal({
                title: "Are you sure?",
                text: "You will not be able to recover this post!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: false
            }, function () {
                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(url('/wpdel')); ?>',
                    data: {
                        'id': id
                    },
                    success: function (data) {
                        if (data == 'success') {
                            swal('Success', 'Deleted', 'success');
                        }
                        else {
                            swal('Error', data, 'error');
                        }
                    }
                })
            });


        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>