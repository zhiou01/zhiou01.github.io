<?php $__env->startSection('title','Twitter Scraper'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="content-wrapper">
            <section class="content">


                
                <div class="box">
                    <div class="box-header">
                        <div align="center" class="row">
                            <div class="col-md-6">
                                <input id="query" placeholder="Type here what you are looking for" class="form-control">
                            </div>
                            <div class="col-md-2">
                                <select id="type" class="form-control">
                                    <option value="tweets">Tweets</option>
                                    <option value="user">User</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <input class="form-control" placeholder="Limit" value="10" type="text" id="limit">
                            </div>
                            <div class="col-md-2">
                                <button id="search" class="btn btn-success"><i class="fa fa-search"></i> Search</button>
                            </div>
                        </div>
                    </div>

                    <div id="scraper" class="box-body">
                        
                    </div>
                    

                    


                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>

        $('#search').click(function () {

            if ($('#query').val() == '') {
                return swal('Please enter keyword');
            }
            else {
                $('#scraper').html(
                    '<div align="center"><h3>Searching ......</h3><br><img src="<?php echo e(url('/images/optimus/social/loader.gif')); ?>">'
                );
                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(url('/tw/scraper')); ?>',
                    data: {
                        'data': $('#query').val(),
                        'limit': $('#limit').val(),
                        'type': $('#type').val()
                    },
                    success: function (data) {
                        $('#scraper').html(data);
//                        $('#scraper').html("finish");
//                            console.log(data);
                        var table = $('#mytable').DataTable({

                            dom: '<""flB>tip',
                            buttons: [
                                {
                                    extend: 'excel',
                                    text: '<button class="btn btn-success btn-xs fak"><i class="fa fa-file-excel-o"></i> Export all to excel</button>'
                                },
                                {
                                    extend: 'csv',
                                    text: '<button class="btn btn-warning btn-xs fak"><i class="fa fa-file-o"></i> Export all to csv</button>'
                                },
                                {
                                    extend: 'pdf',
                                    text: '<button class="btn btn-danger btn-xs fak"><i class="fa fa-file-pdf-o"></i> Print all in pdf</button>'
                                },
                                {
                                    extend: 'print',
                                    text: '<button class="btn btn-default btn-xs fak"><i class="fa fa-print"></i> Print all</button>'
                                },
                            ]
                        });
                    }
                });
            }
        });

    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <script src="<?php echo e(url('/opt/sweetalert.min.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/opt/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>