

<?php $__env->startSection('title','Linkedin Updates'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="content-wrapper">
            <section class="content">
                <div id="liUpdates"></div>
                
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-md-8">
                            <!-- Box Comment -->
                            <div class="box box-widget">
                                <div class="box-header with-border">
                                    <div class="user-block">
                                        <img class="img-circle" src="<?php echo e(url('/images/optimus/social/me.png')); ?>"
                                             alt="User Image">
                                        <span class="username"><a
                                                    href="#"><?php echo e($data['updateContent']['company']['name']); ?></a></span>
                                        <span class="description"><script>document.write(new Date(<?php echo e($data['timestamp']); ?>));</script></span>
                                    </div>
                                    <!-- /.user-block -->
                                    <div class="box-tools">
                                        <button type="button" class="btn btn-box-tool" data-toggle="tooltip" title=""
                                        >
                                            <i class="fa fa-circle-o"></i></button>
                                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i
                                                    class="fa fa-minus"></i>
                                        </button>
                                        <button type="button" class="btn btn-box-tool" data-widget="remove"><i
                                                    class="fa fa-times"></i></button>
                                    </div>
                                    <!-- /.box-tools -->
                                </div>
                                <!-- /.box-header -->
                                <div class="box-body">
                                    <!-- post text -->

                                    <p><?php echo e($data['updateContent']['companyStatusUpdate']['share']['comment']); ?></p>


                                    <span class="pull-right text-muted"><?php echo e($data['numLikes']); ?>

                                        likes - <?php if($data['updateComments']['_total'] == 0): ?>No
                                        comments <?php else: ?> <?php echo e($data['updateComments']['_total']); ?> comments <?php endif; ?></span>
                                </div>
                                <!-- /.box-body -->
                                <?php if($data['updateComments']['_total'] != 0): ?>

                                    <div class="box-footer box-comments">
                                        <?php $__currentLoopData = $data['updateComments']['values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="box-comment">
                                                <!-- User image -->
                                                <?php if(isset($comment['person'])): ?>
                                                    <img class="img-circle img-sm"
                                                         src="<?php echo e(url('/images/optimus/social/linkedin.png')); ?>"
                                                         alt="User Image">
                                                <?php else: ?>
                                                    <img class="img-circle img-sm"
                                                         src="<?php echo e(url('/images/optimus/social/me.png')); ?>"
                                                         alt="User Image">
                                                <?php endif; ?>


                                                <div class="comment-text">
                      <span class="username">
                        <?php if(isset($comment['person'])): ?>
                              <?php echo e($comment['person']['firstName'] ." ".$comment['person']['lastName']); ?>

                          <?php else: ?>
                              <?php echo e($comment['company']['name']); ?>

                          <?php endif; ?>
                          <span class="text-muted pull-right"><script>document.write(new Date(<?php echo e($comment['timestamp']); ?>));</script></span>
                      </span><!-- /.username -->
                                                    <?php echo e($comment['comment']); ?>

                                                </div>
                                                <!-- /.comment-text -->
                                            </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <!-- /.box-comment -->
                                    </div>
                            <?php endif; ?>

                        </div>
                    </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                


            </section><!-- /.content -->

        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>