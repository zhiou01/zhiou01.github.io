<table class="table table-bordered">
    <thead>
    <td>Title</td>
    <td>Time</td>
    <td><i style="color: green" class="fa fa-arrow-circle-up"></i> Ups</td>

    <td><i style="color: red" class="fa fa-arrow-circle-down"></i> Downs</td>
    <td>Url</td>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><b><?php echo e($datum['data']['title']); ?></b></td>
            <td><?php echo e(\Carbon\Carbon::createFromTimestamp($datum['data']['created'])->diffForHumans()); ?></td>
            <td><b style="color: green"><?php echo e($datum['data']['ups']); ?></b></td>
            <td><b style="color: red"> <?php echo e($datum['data']['downs']); ?></b></td>
            <td><a href="<?php echo e($datum['data']['url']); ?>" target="_blank">Click here</a></td>
        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>