<?php if($message == 'nogroup'): ?>
    <?php echo e(die("Group not found ho to home page . <a href='".url('/home')."'>Click here</a>")); ?>


<?php endif; ?>

<?php $__env->startSection('title','Facebook'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="content-wrapper">
            <section class="content">

                <div class="row">

                    <div class="col-md-12">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <?php $tabCount = 0;?>
                                
                                <?php $__currentLoopData = $data['groups']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNo => $pageData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li <?php if($tabCount == 0): ?> class="active" <?php endif; ?>><a href="#<?php echo e($pageData['id']); ?>"
                                                                                     data-toggle="tab"><?php echo e($pageData['name']); ?></a>
                                    </li>
                                    <?php $tabCount++;?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                            <div class="tab-content">
                                
                                <?php $tabContentCount = 0;?>
                                <?php $__currentLoopData = $data['groups']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNo => $pageData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="<?php if($tabContentCount == 0): ?> active <?php endif; ?> tab-pane"
                                         id="<?php echo e($pageData['id']); ?>">
                                        <!-- Post -->
                                        
                                        <?php $__currentLoopData = $pageData['feed']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contentNo => $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(isset($content['id'])): ?>
                                                <div class="post">
                                                    <div class="user-block">
                                                        <img class="img-circle img-bordered-sm"
                                                             src="<?php if(isset($content['from']['picture']['data']['url'])): ?><?php echo e($content['from']['picture']['data']['url']); ?> <?php else: ?> /images/optimus/social/me.png <?php endif; ?>"
                                                             alt="user image">
                                                        <span class='username'>
                                      <a target="_blank"
                                         href="http://facebook.com/<?php if(isset($content['from']['id'])): ?><?php echo e($content['from']['id']); ?> <?php endif; ?>"><?php if(isset($content['from']['name'])): ?> <?php echo e($content['from']['name']); ?> <?php endif; ?></a>


                                        <div class="optimusfbcom" data-id="<?php echo e($content['id']); ?>"
                                             data-token="<?php echo e($token); ?>"><a
                                                    class='pull-right btn-box-tool'><i
                                                        class='fa fa-times'></i></a></div>
                                        <div class="optimusfbedit"
                                             data-value="<?php if(isset($content['message'])): ?><?php echo e($content['message']); ?><?php else: ?> No feed found <?php endif; ?>"
                                             data-id="<?php echo e($content['id']); ?>"
                                             data-token="<?php echo e($token); ?>"><a
                                                    class='pull-right btn-box-tool'><i class='fa fa-edit'></i></a></div>
                                    </span>
                                                        <span class='description'><a
                                                                    href="http://facebook.com/<?php echo e($content['id']); ?>"
                                                                    target="_blank"> <?php echo e(\App\Http\Controllers\Prappo::date($content['created_time'])); ?></a></span>
                                                    </div><!-- /.user-block -->
                                                    <p>
                                                        <!-- feed section start -->

                                                        <?php if(isset($content['message'])): ?>
                                                            <?php echo e($content['message']); ?>

                                                        <?php else: ?>
                                                            No feed found
                                                    <?php endif; ?>

                                                    <!-- feed section end -->

                                                    </p>
                                                    
                                                    <a href="<?php if(isset($content['link'])): ?>
                                                    <?php echo e($content['link']); ?>

                                                    <?php else: ?>
                                                            #
                                                            <?php endif; ?>
                                                            " target="_blank">Link</a><br>

                                                    

                                                    <?php if(isset($content['reactions'])): ?>
                                                        <?php $likes = 0;$love = 0;$haha = 0;$wow = 0;$sad = 0;$angry = 0;$totalReactions = 0; ?>
                                                        <?php $__currentLoopData = $content['reactions']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reactionNo=>$reactions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            
                                                            <?php if($reactions['type']=='LIKE'): ?>
                                                                <?php $likes++;$totalReactions++;?>
                                                            <?php elseif($reactions['type']=='LOVE'): ?>
                                                                <?php $love++;$totalReactions++;?>
                                                            <?php elseif($reactions['type']=='SAD'): ?>
                                                                <?php $sad++;$totalReactions++;?>
                                                            <?php elseif($reactions['type']=='HAHA'): ?>
                                                                <?php $haha++;$totalReactions++;?>
                                                            <?php elseif($reactions['type']=='WOW'): ?>
                                                                <?php $wow++;$totalReactions++;?>
                                                            <?php elseif($reactions['type']=='ANGRY'): ?>
                                                                <?php $angry++;$totalReactions++;?>
                                                            <?php endif; ?>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    <?php endif; ?>
                                                    <div style="padding-left: 10px" class="row">
                                                        
                                                        <img src="<?php echo e(url('/images/optimus/social/likesmall.gif')); ?>"><?php echo e($likes); ?>

                                                        
                                                        <img src="<?php echo e(url('/images/optimus/social/lovesmall.gif')); ?>"><?php echo e($love); ?>

                                                        
                                                        <img src="<?php echo e(url('/images/optimus/social/hahasmall.gif')); ?>"><?php echo e($haha); ?>

                                                        
                                                        <img src="<?php echo e(url('/images/optimus/social/wowsmall.gif')); ?>"><?php echo e($wow); ?>

                                                        
                                                        <img src="<?php echo e(url('/images/optimus/social/sadsmall.gif')); ?>"><?php echo e($sad); ?>

                                                        
                                                        <img src="<?php echo e(url('/images/optimus/social/angrysmall.gif')); ?>"><?php echo e($angry); ?>


                                                        

                                                    </div>


                                                    </p>
                                                    
                                                    <?php $countComments = 0;?>
                                                    <?php if(isset($content['comments'])): ?>
                                                        <?php $__currentLoopData = $content['comments']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentNo => $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $countComments++;?>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                    <span class="pull-right text-muted"><?php echo e($totalReactions); ?>

                                                        Reactions - <?php echo e($countComments); ?> comments</span><br><br>
                                                    <?php $countComments = 0; ?>
                                                    <?php $likes = 0;$love = 0;$haha = 0;$wow = 0;$sad = 0;$angry = 0;$totalReactions = 0; ?>

                                                    

                                                    
                                                    <?php if(isset($content['comments'])): ?>
                                                        <?php $__currentLoopData = $content['comments']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comNo => $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(isset($com['message'])): ?>
                                                                <div style="padding-left: 20px" class="post">
                                                                    <div class="user-block">
                                                                        <img class="img-circle img-bordered-sm"
                                                                             src="<?php echo e(url('/images/optimus/social/me.png')); ?>"
                                                                             alt="user image">
                                                                        <span class='username'>
                                                          <a target="_blank"
                                                             href="http://facebook.com/<?php if(isset($com['from']['id'])): ?><?php echo e($com['from']['id']); ?><?php endif; ?>"><?php if(isset($com['from']['name'])): ?><?php echo e($com['from']['name']); ?><?php endif; ?></a>
                                                          <div class="optimusfbcom" data-id="<?php echo e($com['id']); ?>"
                                                               data-token="<?php echo e($token); ?>"><a
                                                                      class='pull-right btn-box-tool'><i
                                                                          class='fa fa-times'></i></a></div>
                                                        </span>
                                                                        <span class='description'><a
                                                                                    href="http://facebook.com/<?php echo e($com['id']); ?>"
                                                                                    target="_blank"> <?php echo e(\App\Http\Controllers\Prappo::date($com['created_time'])); ?></a></span>
                                                                    </div><!-- /.user-block -->
                                                                    <p>
                                                                        <?php echo e($com['message']); ?>


                                                                    </p>
                                                                    
                                                                    <?php if(isset($com['comments'])): ?>
                                                                        <?php $__currentLoopData = $com['comments']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subComNo => $subCom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <div style="padding-left: 30px;"
                                                                                 class="post">
                                                                                <div class="user-block">

                                                                                    <img class="img-circle img-bordered-sm"
                                                                                         src="<?php echo e(url('/images/optimus/social/me.png')); ?>"
                                                                                         alt="user image">
                                                                                    <span class='username'>
                                                                          <a target="_blank"
                                                                             href="http://facebook.com/<?php echo e($subCom['id']); ?>"><?php if(isset($subCom['from']['name'])): ?><?php echo e($subCom['from']['name']); ?><?php endif; ?></a>
                                                                          <div class="optimusfbcom"
                                                                               data-id="<?php echo e($subCom['id']); ?>"
                                                                               data-token="<?php echo e($token); ?>"><a
                                                                                      class='pull-right btn-box-tool'><i
                                                                                          class='fa fa-times'></i></a></div>
                                                                        </span>
                                                                                    <span class='description'><a
                                                                                                href="http://facebook.com/<?php echo e($subCom['id']); ?>"
                                                                                                target="_blank"><?php echo e(\App\Http\Controllers\Prappo::date($subCom['created_time'])); ?></a> </span>
                                                                                </div><!-- /.user-block -->
                                                                                <p>
                                                                                    <?php echo e($subCom['message']); ?>

                                                                                </p>


                                                                            </div>


                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                    <?php endif; ?>

                                                                    
                                                                    <div style="padding-left: 20px"
                                                                         class="form-horizontal">
                                                                        <div class="form-group margin-bottom-none">
                                                                            <div class="col-sm-10">
                                                                                <input class="form-control input-sm"
                                                                                       data-id="<?php echo e($com['id']); ?>"
                                                                                       data-token="<?php echo e($token); ?>"
                                                                                       placeholder="Replay.. ">
                                                                            </div>

                                                                        </div>
                                                                    </div>
                                                                    <br>

                                                                    

                                                                    

                                                                </div><!-- /.post -->
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>


                                                    

                                                    

                                                    <div class="form-horizontal">
                                                        <div class="form-group margin-bottom-none">
                                                            <div class="col-sm-12">
                                                                <input class="form-control input-sm"
                                                                       data-id="<?php echo e($content['id']); ?>"
                                                                       data-token="<?php echo e($token); ?>"
                                                                       placeholder="Comment">
                                                            </div>

                                                        </div>
                                                    </div>

                                                </div><!-- /.post -->

                                                <!-- Post -->
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div><!-- /.tab-pane -->
                                <?php $tabContentCount++;?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- /.tab-pane -->


                            </div><!-- /.tab-content -->
                        </div><!-- /.nav-tabs-custom -->
                    </div><!-- /.col -->
                </div><!-- /.row -->

            </section><!-- /.content -->

        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {

        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <script src="<?php echo e(url('/opt/sweetalert.min.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/opt/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>