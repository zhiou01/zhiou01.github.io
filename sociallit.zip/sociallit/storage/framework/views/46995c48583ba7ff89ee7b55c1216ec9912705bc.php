<header class="main-header">
    <nav class="navbar navbar-static-top">
        <div class="container">
            <div class="navbar-header">
                <a href="" class="navbar-brand"><b>Social</b>Lit</a>
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#navbar-collapse">
                    <i class="fa fa-bars"></i>
                </button>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
                <ul class="nav navbar-nav">


                    <?php if(\App\Http\Controllers\Data::myPackage('fb')): ?>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-facebook"></i>
                                <span><?php echo e(trans('sidebar.Facebook')); ?></span><span class="caret"></span>

                            </a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(url('/facebook')); ?>"><?php echo e(trans('sidebar.Facebook Pages')); ?> </a></li>
                                
                                <li><a href="<?php echo e(url('/conversations')); ?>"><?php echo e(trans('sidebar.Conversations')); ?> </a></li>
                                <li><a href="<?php echo e(url('/campaign')); ?>">Campaign </a></li>
                                <li><a href="<?php echo e(url('/capture')); ?>">Capture </a></li>
                                <li><a href="<?php echo e(url('/fb/bot')); ?>">Messenger Bot </a></li>
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                <li><a href="<?php echo e(url('/masssend')); ?>"><?php echo e(trans('sidebar.Facebook Mass Send')); ?> </a></li>
                                <li><a href="<?php echo e(url('extend')); ?>"><?php echo e(trans('sidebar.Extend')); ?> </a></li>
                                <li><a href="<?php echo e(url('scraper')); ?>"><?php echo e(trans('sidebar.Facebook Scraper')); ?> </a></li>
                                <li><a href="<?php echo e(url('/rss')); ?>">RSS to Facebook </a></li>
                                <li><a href="<?php echo e(url('/web')); ?>">Web to Facebook </a></li>

                                <?php echo \App\Http\Controllers\Plugins::menu("facebook"); ?>


                            </ul>
                        </li>


                    <?php endif; ?>


                    
                    <?php if(\App\Http\Controllers\Data::myPackage('tw')): ?>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-twitter"></i>
                                <span><?php echo e(trans('sidebar.Twitter')); ?></span>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo e(url('/twitter')); ?>">
                                        <span><?php echo e(trans('sidebar.My account')); ?></span></a>
                                </li>
                                <li><a href="<?php echo e(url('/twitter/message/send')); ?>">
                                        <span><?php echo e(trans('sidebar.Send Direct Message')); ?></span></a>
                                </li>

                                <li><a href="<?php echo e(url('/twitter/masssend')); ?>">
                                        <span><?php echo e(trans('sidebar.Mass Message Send')); ?></span></a></li>
                                
                                

                                <li><a href="<?php echo e(url('/twitter/autoretweet')); ?>">
                                        <span><?php echo e(trans('sidebar.Mass Retweet')); ?></span></a></li>

                                <li><a href="<?php echo e(url('/twitter/autoretweet/hashtag')); ?>">
                                        <span><?php echo e(trans('sidebar.Auto Retweet Hashtag')); ?></span></a></li>

                                <li><a href="<?php echo e(url('/twitter/autoreply')); ?>">
                                        <span><?php echo e(trans('sidebar.Mass Reply')); ?></span></a></li>
                                <li><a href="<?php echo e(url('/tw/scraper')); ?>"><?php echo e(trans('sidebar.Twitter Scraper')); ?> </a></li>
                                <li><a href="<?php echo e(url('/rss')); ?>">RSS To Twitter </a></li>
                                <li><a href="<?php echo e(url('/web')); ?>">Web To Twitter </a></li>
                                <?php echo \App\Http\Controllers\Plugins::menu("twitter"); ?>

                            </ul>

                        </li>
                    <?php endif; ?>

                    
                    <?php if(\App\Http\Controllers\Data::myPackage('in')): ?>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-instagram"></i>
                                <span><?php echo e(trans('sidebar.Instagram')); ?></span>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(url('/instagram/me')); ?>">
                                        <span><?php echo e(trans('sidebar.My account')); ?></span></a>
                                <li><a href="<?php echo e(url('/instagram/home')); ?>">
                                        <span><?php echo e(trans('sidebar.Home')); ?></span></a>
                                <li><a href="<?php echo e(url('/instagram/popular')); ?>"></i>
                                        <span><?php echo e(trans('sidebar.Popular Feed')); ?> </span></a>
                                <li>
                                    <a href="<?php echo e(url('/instagram/followers')); ?>"><span><?php echo e(trans('sidebar.Followers')); ?> </span></a>
                                <li>
                                    <a href="<?php echo e(url('/instagram/following')); ?>"><span><?php echo e(trans('sidebar.Following')); ?> </span></a>
                                <li>
                                    <a href="<?php echo e(url('/instagram/following/activity')); ?>"><span><?php echo e(trans('sidebar.Following Activity')); ?> </span></a>
                                <li>
                                    <a href="<?php echo e(url('/instagram/auto/follow')); ?>"><span><?php echo e(trans('sidebar.Auto follow')); ?> </span></a>
                                <li>
                                    <a href="<?php echo e(url('/instagram/auto/unfollow')); ?>"><span><?php echo e(trans('sidebar.Auto unfollow')); ?> </span></a>
                                <li>
                                    <a href="<?php echo e(url('/instagram/auto/comments')); ?>"><span><?php echo e(trans('sidebar.Auto comment')); ?> </span></a>
                                
                                <li><a href="<?php echo e(url('/instagram/scraper')); ?>">
                                        <span><?php echo e(trans('sidebar.Scraper')); ?></span></a>
                                </li>

                                </li>
                                <?php echo \App\Http\Controllers\Plugins::menu("instagram"); ?>


                            </ul>

                        </li>
                    <?php endif; ?>



                    
                    <?php if(\App\Http\Controllers\Data::myPackage('pinterest')): ?>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-pinterest"></i>
                                <span><?php echo e(trans('sidebar.Pinterest')); ?></span>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu" role="menu">


                                <li><a href="<?php echo e(url('/pinterest/pins')); ?>">
                                        <span>My Pins</span></a>
                                </li>

                                <li><a href="<?php echo e(url('/pinterest/home')); ?>">
                                        <span>Home</span></a>
                                </li>


                                
                                
                                

                                
                                
                                

                                <li><a href="<?php echo e(url('/pinterest/scraper')); ?>">
                                        <span><?php echo e(trans('sidebar.Scraper')); ?></span></a>
                                </li>

                                <li><a href="<?php echo e(url('/pinterest/auto/comment')); ?>">
                                        <span>Auto Comment & Repin</span></a>
                                </li>

                                <li><a href="<?php echo e(url('/pinterest/auto/repin')); ?>">
                                        <span>Auto Repin</span></a>
                                </li>

                                <?php echo \App\Http\Controllers\Plugins::menu("pinterest"); ?>

                            </ul>

                        </li>
                    <?php endif; ?>
                    

                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-globe"></i>
                            <span>Web To Social</span>
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="<?php echo e(url('/rss')); ?>">
                                    <span>RSS to Social Media</span></a>
                            </li>

                            <li><a href="<?php echo e(url('/web')); ?>">
                                    <span>Web To Social</span></a>
                            </li>

                        </ul>

                    </li>


                    <?php if(\App\Http\Controllers\Data::myPackage('ln')): ?>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-linkedin"></i>
                                <span><?php echo e(trans('sidebar.Linkedin')); ?></span>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(url('/linkedin/updates')); ?>">
                                        <span><?php echo e(trans('sidebar.All updates')); ?></span></a>
                                </li>
                                <li><a href="<?php echo e(url('/linkedin/mass_comment')); ?>">
                                        <span><?php echo e(trans('sidebar.Mass Comment')); ?></span></a></li>
                                <?php echo \App\Http\Controllers\Plugins::menu("linkedin"); ?>

                            </ul>

                        </li>
                    <?php endif; ?>

                    
                    <?php if(\App\Http\Controllers\Data::myPackage('tu')): ?>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-tumblr-square"></i>
                                <span><?php echo e(trans('sidebar.Tumblr')); ?></span>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(url('/tumblr')); ?>">
                                        <span><?php echo e(trans('sidebar.Tumblr')); ?></span></a></li>
                                <?php echo \App\Http\Controllers\Plugins::menu("tumblr"); ?>

                            </ul>
                        </li>
                    <?php endif; ?>
                    
                    <?php if(\App\Http\Controllers\Data::myPackage('wp')): ?>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wordpress"></i>
                                <span><?php echo e(trans('sidebar.Wordpress')); ?> </span>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(url('/wordpress')); ?>">
                                        <span><?php echo e(trans('sidebar.Wordpress')); ?></span></a>
                                </li>
                                <?php echo \App\Http\Controllers\Plugins::menu("wordpress"); ?>

                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if(\App\Http\Controllers\Data::myPackage('pack1')): ?>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-reddit"></i>
                                <span>Reddit </span>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(url('/reddit')); ?>">
                                        <span>Search</span></a>
                                </li>
                                <?php echo \App\Http\Controllers\Plugins::menu("pack1"); ?>

                            </ul>
                        </li>
                    <?php endif; ?>

                    <li>
                        <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
                    </li>


                </ul>

            </div>
            <!-- /.navbar-collapse -->

            <!-- /.navbar-custom-menu -->
        </div>
        <!-- /.container-fluid -->
    </nav>
</header>