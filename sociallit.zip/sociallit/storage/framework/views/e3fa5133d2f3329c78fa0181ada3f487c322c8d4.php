<?php $__env->startSection('title','Schedule days'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div class="content-wrapper">
            <section class="content">
                <div class="row">
                    <div class="box no-border">
                        <form action="<?php echo e(url('/schedule/filter')); ?>" method="post">


                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>From</label>

                                        <div class="input-group date">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input class="form-control pull-left"
                                                   <?php if(isset($_POST['from'])): ?> value="<?php echo e($_POST['from']); ?>"
                                                   <?php endif; ?> type="date" name="from">
                                        </div>
                                        <!-- /.input group -->
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>To</label>

                                        <div class="input-group date">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input class="form-control pull-right"
                                                   <?php if(isset($_POST['to'])): ?> value="<?php echo e($_POST['to']); ?>" <?php endif; ?> type="date"
                                                   name="to">
                                        </div>
                                        <!-- /.input group -->
                                    </div>
                                </div>
                                <div class="col-md-2" style="margin-top:5px">
                                    <div class="form-group">
                                        <label></label>

                                        <div class="input-group date">

                                            <button type="submit" class="btn btn-block btn-success"><i
                                                        class="fa fa-search"></i> Search
                                            </button>
                                        </div>
                                        <!-- /.input group -->
                                    </div>


                                </div>

                                <div class="col-md-4" style="margin-top:25px">
                                    <div class="btn-group">
                                        <a href="<?php echo e(url('/schedule/filter/week')); ?>" class="btn btn-default"><i class="fa fa-calendar"></i> This week</a>
                                        <a href="<?php echo e(url('/schedule/filter/month')); ?>" class="btn btn-default"><i class="fa fa-calendar"></i> This month</a>
                                        <a href="<?php echo e(url('/schedule/filter/all')); ?>" class="btn btn-default"><i class="fa fa-calendar"></i> All</a>
                                    </div>
                                </div>
                            </div>


                        </form>


                    </div>

                </div>
                <div class="row daysbox">
                    <div class="dayBox">
                        <div class="dayHead">
                            Monday
                        </div>

                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(\Carbon\Carbon::parse($da->time)->format('l') == "Monday"): ?>
                                <div class="row">
                                    <div class="box">
                                        <div class="box-header">
                                                <span class="sTime"><i
                                                            class="fa fa-clock-o"></i> <?php echo e(\Carbon\Carbon::parse($da->time)->toTimeString()); ?></span>
                                        </div>
                                        <div class="box-body">

                                            <?php if($da->image != ""): ?>
                                                <img width="100%" src="<?php echo e(url('/uploads')); ?>/<?php echo e($da->image); ?>">
                                            <?php else: ?>
                                                <br>
                                            <?php endif; ?>
                                            <h4>
                                                <?php if($da->fb == "yes"): ?>
                                                    <i class="fa fa-facebook-official"></i>
                                                <?php endif; ?>
                                                <?php if($da->fbg == "yes"): ?>
                                                    <i class="fa fa-users"></i>
                                                <?php endif; ?>
                                                <?php if($da->tw == "yes"): ?>
                                                    <i class="fa fa-twitter"></i>
                                                <?php endif; ?>
                                                <?php if($da->tu == "yes"): ?>
                                                    <i class="fa fa-tumblr"></i>
                                                <?php endif; ?>
                                                <?php if($da->wp == "yes"): ?>
                                                    <i class="fa fa-wordpress"></i>
                                                <?php endif; ?>
                                                <?php if($da->instagram == "yes"): ?>
                                                    <i class="fa fa-instagram"></i>

                                                <?php endif; ?>
                                                <?php if($da->pinterest == "yes"): ?>
                                                    <i class="fa fa-pinterest"></i>
                                                <?php endif; ?>

                                                <?php echo e($da->title); ?></h4>
                                            <p>
                                                <?php echo e($da->content); ?>

                                            </p>
                                            <?php if($da->published == "yes"): ?>
                                                <button type="button" class="btn btn-block btn-xs bg-olive">
                                                    Published
                                                </button>
                                            <?php else: ?>
                                                <button data-id="<?php echo e($da->id); ?>" type="button"
                                                        class="btn btn-block btn-warning btn-xs scheduled">
                                                    <i class="fa fa-edit"></i> Edit Time / Delete
                                                </button>
                                                <div id="<?php echo e($da->id); ?>" style="display:none;" align="center">
                                                    <hr>
                                                    <input type="datetime-local"
                                                           value="<?php echo e(\Carbon\Carbon::parse($da->time)->format("Y-m-d\TH:i:s")); ?>"
                                                           class="time_<?php echo e($da->id); ?> form-control" id="time">
                                                    <hr>
                                                    <div class="btn-group">
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn btnSave  btn-success btn-xs"><i
                                                                    class="fa fa-save"></i>
                                                        </button>
                                                        <button class="sDel btn-xs btn bg-red-gradient"
                                                                data-id="<?php echo e($da->id); ?>"><i class="fa fa-trash"></i>
                                                        </button>
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn  btn-danger btn-xs"><i
                                                                    class="fa fa-times"></i>
                                                        </button>
                                                    </div>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="dayBox">
                        <div class="dayHead">
                            Tuesday
                        </div>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(\Carbon\Carbon::parse($da->time)->format('l') == "Tuesday"): ?>
                                <div class="row">
                                    <div class="box">
                                        <div class="box-header">
                                                <span class="sTime"><i
                                                            class="fa fa-clock-o"></i> <?php echo e(\Carbon\Carbon::parse($da->time)->toTimeString()); ?></span>
                                        </div>
                                        <div class="box-body">

                                            <?php if($da->image != ""): ?>
                                                <img width="100%" src="<?php echo e(url('/uploads')); ?>/<?php echo e($da->image); ?>">
                                            <?php else: ?>
                                                <br>
                                            <?php endif; ?>
                                            <h4>
                                                <?php if($da->fb == "yes"): ?>
                                                    <i class="fa fa-facebook-official"></i>
                                                <?php endif; ?>
                                                <?php if($da->fbg == "yes"): ?>
                                                    <i class="fa fa-users"></i>
                                                <?php endif; ?>
                                                <?php if($da->tw == "yes"): ?>
                                                    <i class="fa fa-twitter"></i>
                                                <?php endif; ?>
                                                <?php if($da->tu == "yes"): ?>
                                                    <i class="fa fa-tumblr"></i>
                                                <?php endif; ?>
                                                <?php if($da->wp == "yes"): ?>
                                                    <i class="fa fa-wordpress"></i>
                                                <?php endif; ?>
                                                <?php if($da->instagram == "yes"): ?>
                                                    <i class="fa fa-instagram"></i>

                                                <?php endif; ?>
                                                <?php if($da->pinterest == "yes"): ?>
                                                    <i class="fa fa-pinterest"></i>
                                                <?php endif; ?>

                                                <?php echo e($da->title); ?></h4>
                                            <p>
                                                <?php echo e($da->content); ?>

                                            </p>
                                            <?php if($da->published == "yes"): ?>
                                                <button type="button" class="btn btn-block btn-xs bg-olive">
                                                    Published
                                                </button>
                                            <?php else: ?>
                                                <button data-id="<?php echo e($da->id); ?>" type="button"
                                                        class="btn btn-block btn-warning btn-xs scheduled">
                                                    <i class="fa fa-edit"></i> Edit Time / Delete
                                                </button>
                                                <div id="<?php echo e($da->id); ?>" style="display:none;" align="center">
                                                    <hr>
                                                    <input type="datetime-local"
                                                           value="<?php echo e(\Carbon\Carbon::parse($da->time)->format("Y-m-d\TH:i:s")); ?>"
                                                           class="time_<?php echo e($da->id); ?> form-control" id="time">
                                                    <hr>
                                                    <div class="btn-group">
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn btnSave  btn-success btn-xs"><i
                                                                    class="fa fa-save"></i>
                                                        </button>
                                                        <button class="sDel btn-xs btn bg-red-gradient"
                                                                data-id="<?php echo e($da->id); ?>"><i class="fa fa-trash"></i>
                                                        </button>
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn  btn-danger btn-xs"><i
                                                                    class="fa fa-times"></i>
                                                        </button>
                                                    </div>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="dayBox">
                        <div class="dayHead">
                            Wednesday
                        </div>

                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(\Carbon\Carbon::parse($da->time)->format('l') == "Wednesday"): ?>
                                <div class="row">
                                    <div class="box">
                                        <div class="box-header">
                                                <span class="sTime"><i
                                                            class="fa fa-clock-o"></i> <?php echo e(\Carbon\Carbon::parse($da->time)->toTimeString()); ?></span>
                                        </div>
                                        <div class="box-body">

                                            <?php if($da->image != ""): ?>
                                                <img width="100%" src="<?php echo e(url('/uploads')); ?>/<?php echo e($da->image); ?>">
                                            <?php else: ?>
                                                <br>
                                            <?php endif; ?>
                                            <h4>
                                                <?php if($da->fb == "yes"): ?>
                                                    <i class="fa fa-facebook-official"></i>
                                                <?php endif; ?>
                                                <?php if($da->fbg == "yes"): ?>
                                                    <i class="fa fa-users"></i>
                                                <?php endif; ?>
                                                <?php if($da->tw == "yes"): ?>
                                                    <i class="fa fa-twitter"></i>
                                                <?php endif; ?>
                                                <?php if($da->tu == "yes"): ?>
                                                    <i class="fa fa-tumblr"></i>
                                                <?php endif; ?>
                                                <?php if($da->wp == "yes"): ?>
                                                    <i class="fa fa-wordpress"></i>
                                                <?php endif; ?>
                                                <?php if($da->instagram == "yes"): ?>
                                                    <i class="fa fa-instagram"></i>

                                                <?php endif; ?>
                                                <?php if($da->pinterest == "yes"): ?>
                                                    <i class="fa fa-pinterest"></i>
                                                <?php endif; ?>

                                                <?php echo e($da->title); ?></h4>
                                            <p>
                                                <?php echo e($da->content); ?>

                                            </p>
                                            <?php if($da->published == "yes"): ?>
                                                <button type="button" class="btn btn-block btn-xs bg-olive">
                                                    Published
                                                </button>
                                            <?php else: ?>
                                                <button data-id="<?php echo e($da->id); ?>" type="button"
                                                        class="btn btn-block btn-warning btn-xs scheduled">
                                                    <i class="fa fa-edit"></i> Edit Time / Delete
                                                </button>
                                                <div id="<?php echo e($da->id); ?>" style="display:none;" align="center">
                                                    <hr>
                                                    <input type="datetime-local"
                                                           value="<?php echo e(\Carbon\Carbon::parse($da->time)->format("Y-m-d\TH:i:s")); ?>"
                                                           class="time_<?php echo e($da->id); ?> form-control" id="time">
                                                    <hr>
                                                    <div class="btn-group">
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn btnSave  btn-success btn-xs"><i
                                                                    class="fa fa-save"></i>
                                                        </button>
                                                        <button class="sDel btn-xs btn bg-red-gradient"
                                                                data-id="<?php echo e($da->id); ?>"><i class="fa fa-trash"></i>
                                                        </button>
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn  btn-danger btn-xs"><i
                                                                    class="fa fa-times"></i>
                                                        </button>
                                                    </div>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="dayBox">
                        <div class="dayHead">
                            Thursday
                        </div>

                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(\Carbon\Carbon::parse($da->time)->format('l') == "Thursday"): ?>
                                <div class="row">
                                    <div class="box">
                                        <div class="box-header">
                                                <span class="sTime"><i
                                                            class="fa fa-clock-o"></i> <?php echo e(\Carbon\Carbon::parse($da->time)->toTimeString()); ?></span>
                                        </div>
                                        <div class="box-body">

                                            <?php if($da->image != ""): ?>
                                                <img width="100%" src="<?php echo e(url('/uploads')); ?>/<?php echo e($da->image); ?>">
                                            <?php else: ?>
                                                <br>
                                            <?php endif; ?>
                                            <h4>
                                                <?php if($da->fb == "yes"): ?>
                                                    <i class="fa fa-facebook-official"></i>
                                                <?php endif; ?>
                                                <?php if($da->fbg == "yes"): ?>
                                                    <i class="fa fa-users"></i>
                                                <?php endif; ?>
                                                <?php if($da->tw == "yes"): ?>
                                                    <i class="fa fa-twitter"></i>
                                                <?php endif; ?>
                                                <?php if($da->tu == "yes"): ?>
                                                    <i class="fa fa-tumblr"></i>
                                                <?php endif; ?>
                                                <?php if($da->wp == "yes"): ?>
                                                    <i class="fa fa-wordpress"></i>
                                                <?php endif; ?>
                                                <?php if($da->instagram == "yes"): ?>
                                                    <i class="fa fa-instagram"></i>

                                                <?php endif; ?>
                                                <?php if($da->pinterest == "yes"): ?>
                                                    <i class="fa fa-pinterest"></i>
                                                <?php endif; ?>

                                                <?php echo e($da->title); ?></h4>
                                            <p>
                                                <?php echo e($da->content); ?>

                                            </p>
                                            <?php if($da->published == "yes"): ?>
                                                <button type="button" class="btn btn-block btn-xs bg-olive">
                                                    Published
                                                </button>
                                            <?php else: ?>
                                                <button data-id="<?php echo e($da->id); ?>" type="button"
                                                        class="btn btn-block btn-warning btn-xs scheduled">
                                                    <i class="fa fa-edit"></i> Edit Time / Delete
                                                </button>
                                                <div id="<?php echo e($da->id); ?>" style="display:none;" align="center">
                                                    <hr>
                                                    <input type="datetime-local"
                                                           value="<?php echo e(\Carbon\Carbon::parse($da->time)->format("Y-m-d\TH:i:s")); ?>"
                                                           class="time_<?php echo e($da->id); ?> form-control" id="time">
                                                    <hr>
                                                    <div class="btn-group">
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn btnSave  btn-success btn-xs"><i
                                                                    class="fa fa-save"></i>
                                                        </button>
                                                        <button class="sDel btn-xs btn bg-red-gradient"
                                                                data-id="<?php echo e($da->id); ?>"><i class="fa fa-trash"></i>
                                                        </button>
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn  btn-danger btn-xs"><i
                                                                    class="fa fa-times"></i>
                                                        </button>
                                                    </div>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="dayBox">
                        <div class="dayHead">
                            Friday
                        </div>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(\Carbon\Carbon::parse($da->time)->format('l') == "Friday"): ?>
                                <div class="row">
                                    <div class="box">
                                        <div class="box-header">
                                                <span class="sTime"><i
                                                            class="fa fa-clock-o"></i> <?php echo e(\Carbon\Carbon::parse($da->time)->toTimeString()); ?></span>
                                        </div>
                                        <div class="box-body">

                                            <?php if($da->image != ""): ?>
                                                <img width="100%" src="<?php echo e(url('/uploads')); ?>/<?php echo e($da->image); ?>">
                                            <?php else: ?>
                                                <br>
                                            <?php endif; ?>
                                            <h4>
                                                <?php if($da->fb == "yes"): ?>
                                                    <i class="fa fa-facebook-official"></i>
                                                <?php endif; ?>
                                                <?php if($da->fbg == "yes"): ?>
                                                    <i class="fa fa-users"></i>
                                                <?php endif; ?>
                                                <?php if($da->tw == "yes"): ?>
                                                    <i class="fa fa-twitter"></i>
                                                <?php endif; ?>
                                                <?php if($da->tu == "yes"): ?>
                                                    <i class="fa fa-tumblr"></i>
                                                <?php endif; ?>
                                                <?php if($da->wp == "yes"): ?>
                                                    <i class="fa fa-wordpress"></i>
                                                <?php endif; ?>
                                                <?php if($da->instagram == "yes"): ?>
                                                    <i class="fa fa-instagram"></i>

                                                <?php endif; ?>
                                                <?php if($da->pinterest == "yes"): ?>
                                                    <i class="fa fa-pinterest"></i>
                                                <?php endif; ?>

                                                <?php echo e($da->title); ?></h4>
                                            <p>
                                                <?php echo e($da->content); ?>

                                            </p>
                                            <?php if($da->published == "yes"): ?>
                                                <button type="button" class="btn btn-block btn-xs bg-olive">
                                                    Published
                                                </button>
                                            <?php else: ?>
                                                <button data-id="<?php echo e($da->id); ?>" type="button"
                                                        class="btn btn-block btn-warning btn-xs scheduled">
                                                    <i class="fa fa-edit"></i> Edit Time / Delete
                                                </button>
                                                <div id="<?php echo e($da->id); ?>" style="display:none;" align="center">
                                                    <hr>
                                                    <input type="datetime-local"
                                                           value="<?php echo e(\Carbon\Carbon::parse($da->time)->format("Y-m-d\TH:i:s")); ?>"
                                                           class="time_<?php echo e($da->id); ?> form-control" id="time">
                                                    <hr>
                                                    <div class="btn-group">
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn btnSave  btn-success btn-xs"><i
                                                                    class="fa fa-save"></i>
                                                        </button>
                                                        <button class="sDel btn-xs btn bg-red-gradient"
                                                                data-id="<?php echo e($da->id); ?>"><i class="fa fa-trash"></i>
                                                        </button>
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn  btn-danger btn-xs"><i
                                                                    class="fa fa-times"></i>
                                                        </button>
                                                    </div>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="dayBox">
                        <div class="dayHead">
                            Saturday
                        </div>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(\Carbon\Carbon::parse($da->time)->format('l') == "Saturday"): ?>
                                <div class="row">
                                    <div class="box">
                                        <div class="box-header">
                                                <span class="sTime"><i
                                                            class="fa fa-clock-o"></i> <?php echo e(\Carbon\Carbon::parse($da->time)->toTimeString()); ?></span>
                                        </div>
                                        <div class="box-body">

                                            <?php if($da->image != ""): ?>
                                                <img width="100%" src="<?php echo e(url('/uploads')); ?>/<?php echo e($da->image); ?>">
                                            <?php else: ?>
                                                <br>
                                            <?php endif; ?>
                                            <h4>
                                                <?php if($da->fb == "yes"): ?>
                                                    <i class="fa fa-facebook-official"></i>
                                                <?php endif; ?>
                                                <?php if($da->fbg == "yes"): ?>
                                                    <i class="fa fa-users"></i>
                                                <?php endif; ?>
                                                <?php if($da->tw == "yes"): ?>
                                                    <i class="fa fa-twitter"></i>
                                                <?php endif; ?>
                                                <?php if($da->tu == "yes"): ?>
                                                    <i class="fa fa-tumblr"></i>
                                                <?php endif; ?>
                                                <?php if($da->wp == "yes"): ?>
                                                    <i class="fa fa-wordpress"></i>
                                                <?php endif; ?>
                                                <?php if($da->instagram == "yes"): ?>
                                                    <i class="fa fa-instagram"></i>

                                                <?php endif; ?>
                                                <?php if($da->pinterest == "yes"): ?>
                                                    <i class="fa fa-pinterest"></i>
                                                <?php endif; ?>

                                                <?php echo e($da->title); ?></h4>
                                            <p>
                                                <?php echo e($da->content); ?>

                                            </p>
                                            <?php if($da->published == "yes"): ?>
                                                <button type="button" class="btn btn-block btn-xs bg-olive">
                                                    Published
                                                </button>
                                            <?php else: ?>
                                                <button data-id="<?php echo e($da->id); ?>" type="button"
                                                        class="btn btn-block btn-warning btn-xs scheduled">
                                                    <i class="fa fa-edit"></i> Edit Time / Delete
                                                </button>
                                                <div id="<?php echo e($da->id); ?>" style="display:none;" align="center">
                                                    <hr>
                                                    <input type="datetime-local"
                                                           value="<?php echo e(\Carbon\Carbon::parse($da->time)->format("Y-m-d\TH:i:s")); ?>"
                                                           class="time_<?php echo e($da->id); ?> form-control" id="time">
                                                    <hr>
                                                    <div class="btn-group">
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn btnSave  btn-success btn-xs"><i
                                                                    class="fa fa-save"></i>
                                                        </button>
                                                        <button class="sDel btn-xs btn bg-red-gradient"
                                                                data-id="<?php echo e($da->id); ?>"><i class="fa fa-trash"></i>
                                                        </button>
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn  btn-danger btn-xs"><i
                                                                    class="fa fa-times"></i>
                                                        </button>
                                                    </div>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="dayBoxLast">
                        <div class="dayHead">
                            Sunday

                        </div>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(\Carbon\Carbon::parse($da->time)->format('l') == "Sunday"): ?>
                                <div class="row">
                                    <div class="box">
                                        <div class="box-header">
                                                <span class="sTime"><i
                                                            class="fa fa-clock-o"></i> <?php echo e(\Carbon\Carbon::parse($da->time)->toTimeString()); ?></span>
                                        </div>
                                        <div class="box-body">

                                            <?php if($da->image != ""): ?>
                                                <img width="100%" src="<?php echo e(url('/uploads')); ?>/<?php echo e($da->image); ?>">
                                            <?php else: ?>
                                                <br>
                                            <?php endif; ?>
                                            <h4>
                                                <?php if($da->fb == "yes"): ?>
                                                    <i class="fa fa-facebook-official"></i>
                                                <?php endif; ?>
                                                <?php if($da->fbg == "yes"): ?>
                                                    <i class="fa fa-users"></i>
                                                <?php endif; ?>
                                                <?php if($da->tw == "yes"): ?>
                                                    <i class="fa fa-twitter"></i>
                                                <?php endif; ?>
                                                <?php if($da->tu == "yes"): ?>
                                                    <i class="fa fa-tumblr"></i>
                                                <?php endif; ?>
                                                <?php if($da->wp == "yes"): ?>
                                                    <i class="fa fa-wordpress"></i>
                                                <?php endif; ?>
                                                <?php if($da->instagram == "yes"): ?>
                                                    <i class="fa fa-instagram"></i>

                                                <?php endif; ?>
                                                <?php if($da->pinterest == "yes"): ?>
                                                    <i class="fa fa-pinterest"></i>
                                                <?php endif; ?>

                                                <?php echo e($da->title); ?></h4>
                                            <p>
                                                <?php echo e($da->content); ?>

                                            </p>
                                            <?php if($da->published == "yes"): ?>
                                                <button type="button" class="btn btn-block btn-xs bg-olive">
                                                    Published
                                                </button>
                                            <?php else: ?>
                                                <button data-id="<?php echo e($da->id); ?>" type="button"
                                                        class="btn btn-block btn-warning btn-xs scheduled">
                                                    <i class="fa fa-edit"></i> Edit Time / Delete
                                                </button>
                                                <div id="<?php echo e($da->id); ?>" style="display:none;" align="center">
                                                    <hr>
                                                    <input type="datetime-local"
                                                           value="<?php echo e(\Carbon\Carbon::parse($da->time)->format("Y-m-d\TH:i:s")); ?>"
                                                           class="time_<?php echo e($da->id); ?> form-control" id="time">
                                                    <hr>
                                                    <div class="btn-group">
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn btnSave  btn-success btn-xs"><i
                                                                    class="fa fa-save"></i>
                                                        </button>
                                                        <button class="sDel btn-xs btn bg-red-gradient"
                                                                data-id="<?php echo e($da->id); ?>"><i class="fa fa-trash"></i>
                                                        </button>
                                                        <button data-id="<?php echo e($da->id); ?>" type="button"
                                                                class="btn  btn-danger btn-xs"><i
                                                                    class="fa fa-times"></i>
                                                        </button>
                                                    </div>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>

            </section>
        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .row {
            margin: 0px !important;
            padding: 0px !important;
        }

        .dayBox {
            position: relative;
            width: 100%;

            padding: 5px;
            min-height: 500px;
            border-right: 2px dashed darkgray;
        }

        .dayBoxLast {
            position: relative;
            width: 100%;

            padding: 5px;

            min-height: 500px;

        }

        .daysbox {
            display: flex;
            margin: 5px;
            justify-content: space-between;
            background-color: gainsboro;
            border-radius: 3px;

        }

        .dayHead {
            /*position: absolute;*/
            /*top:0px;*/
            border-bottom: 2px dashed darkgray;
            text-align: center;
            font-weight: bolder;
        }

        .sContainer {
            position: relative;
            background-color: white;
            padding: 5px;
            margin: 5px;
            border-radius: 5px;
            box-shadow: 0px 14px 18px 0px rgba(75, 77, 81, 0.14);
            margin-top: 10px;
            margin-bottom: 10px;
        }

        .sContainer img {
            width: 100%;
        }

        .sTime {
            background-image: -moz-linear-gradient(0deg, rgb(234, 54, 104) 0%, rgb(233, 96, 79) 100%);
            background-image: -webkit-linear-gradient(0deg, rgb(234, 54, 104) 0%, rgb(233, 96, 79) 100%);
            background-image: -ms-linear-gradient(0deg, rgb(234, 54, 104) 0%, rgb(233, 96, 79) 100%);
            box-shadow: 0px 14px 18px 0px rgba(234, 54, 104, 0.14);
            border-radius: 5px;
            padding: 2px 5px;
            font-weight: bolder;
            color: white;
            position: absolute;
            z-index: 14;

        }

        .Rounded_Rectangle_3 {
            background-image: -moz-linear-gradient(0deg, rgb(234, 54, 104) 0%, rgb(233, 96, 79) 100%);
            background-image: -webkit-linear-gradient(0deg, rgb(234, 54, 104) 0%, rgb(233, 96, 79) 100%);
            background-image: -ms-linear-gradient(0deg, rgb(234, 54, 104) 0%, rgb(233, 96, 79) 100%);
            box-shadow: 0px 14px 18px 0px rgba(234, 54, 104, 0.14);
            position: absolute;
            left: 612px;
            top: 215px;
            width: 166px;
            height: 51px;
            z-index: 10;
        }

        .colorFb {
            border-bottom: 3px solid #4267B2;
        }

        .colorTw {
            border-bottom: 3px solid #1DA1F2;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        var s = $("#time").val();
        var startDate = new Date(s.replace(/-/g,'/').replace('T',' '));


        flatpickr(".tt", {
            minDate: new Date(), // "today" / "2016-12-20" / 1477673788975
            maxDate: "2017-12-20",
            enableTime: true,
            wrap: true,
            // create an extra input solely for display purposes
            altInput: true,
            altFormat: "F j, Y h:i K",
            time_24hr: false
        });
        $('.scheduled').click(function () {
            var id = $(this).attr('data-id');
            $('#' + id).toggle(200);
        });

        $('.btn-danger').click(function () {
            var id = $(this).attr('data-id');
            $('#' + id).toggle(200);
        });

        $('.btnSave').click(function () {
            var id = $(this).attr('data-id');
            var sTime = $('.time_'+id).val();
//            return alert("ID" + id + " and time " +sTime);
            $.ajax({
                url: '<?php echo e(url('/schedule/time/update')); ?>',
                type: 'POST',
                data: {
                    'id': id,
                    'time': sTime
                },
                success: function (data) {
                    if (data == 'success') {
                        swal("Success", 'Time updated', 'success');
                    } else {
                        swal('Error!', data, 'error');
                    }
                },
                error: function (data) {
                    swal("Error", "Something went wrong check the console message", 'error');
                    console.log(data.responseText);

                }
            });
        })

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>