<?php $__currentLoopData = array_reverse($response['messages']['data']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="direct-chat-msg <?php if($data['from']['id'] == $me): ?>right <?php endif; ?>">
        <div class="direct-chat-info clearfix">
            <span class="direct-chat-name pull-<?php if($data['from']['id'] == $me): ?>right <?php else: ?> left <?php endif; ?>"><?php echo e($data['from']['name']); ?></span>
            <span class="direct-chat-timestamp pull-<?php if($data['from']['id'] == $me): ?>left <?php else: ?> right <?php endif; ?>"><?php echo e(\App\Http\Controllers\Prappo::date($data['created_time'])); ?></span>
        </div>
        <!-- /.direct-chat-info -->
        <?php $__currentLoopData = $response['participants']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $par): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="direct-chat-text">
            <?php echo e($data['message']); ?>

        </div>
        <!-- /.direct-chat-text -->
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>