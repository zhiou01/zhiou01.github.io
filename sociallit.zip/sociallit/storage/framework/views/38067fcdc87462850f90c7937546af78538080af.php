<?php $__env->startSection('title','Instagram | Auto Comments'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div id="settingspage"></div>

        <div class="content-wrapper">
            <section class="content">

                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Auto Comment</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->

                    <div class="box-body">
                        <div class="form-group">
                            <select id="type">
                                <option value="home">Home Feed</option>
                                <option value="popular">Popular Feed</option>
                                <option value="self">Self Timeline</option>
                                <option value="hashtag">Hashtag Feed</option>
                            </select>
                        </div>
                        <div id="message" class="form-group">

                        </div>
                        <div style="display: none" id="tagDiv" class="form-group">
                            <label for="tag">Tag name</label>
                            <input type="text" class="form-control" id="tag" placeholder="Tag name here ">
                        </div>

                        <div class="form-group">
                            <label for="content">Comment</label>
                            <input type="text" class="form-control" id="comment" placeholder="Type here ...">
                        </div>
                        <div class="form-group">
                            <div id="message"></div>
                        </div>


                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="button" id="btnComment" class="btn btn-primary">Submit comment</button>
                    </div>

                </div>

            </section>
        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $('#type').on('change',function () {
        if($(this).val() == "hashtag"){
            $('#tagDiv').show(500);
        }else{
            $('#tagDiv').hide(500);
        }
    });
    $('#btnComment').click(function () {
        $('#message').html("Please wait . trying to make comments . It will take time based on content");
        $.ajax({
           type:'POST',
            url:'<?php echo e(url('/instagram/auto/comment')); ?>',
            data:{
                'type':$('#type').val(),
                'comment':$('#comment').val(),
                'tag':$('#tag').val()
            },success:function (data) {
                $('#message').html(data);
                $.toast("Done !");
            },error:function (data) {
                $('#message').html("Something went wrong , Please check console message");
                console.log(data.responseText);
            }
        });
    })
</script>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>