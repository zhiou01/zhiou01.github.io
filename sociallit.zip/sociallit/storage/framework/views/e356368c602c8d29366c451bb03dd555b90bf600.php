<?php $__env->startSection('title','Instagram | Followers'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div id="settingspage"></div>

        <div class="content-wrapper">
            <section class="content">
                <div class="row">
                <div class="col-md-12">
                    <!-- USERS LIST -->
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">Followers</h3>

                        </div>
                        <!-- /.box-header -->
                        <div class="box-body no-padding">
                            <ul class="users-list clearfix">
                                <?php $__currentLoopData = $datas->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>

                                        <img src="<?php echo e($data->profile_pic_url); ?>" alt="User Image">
                                        <a target="_blank" class="users-list-name" href="https://instagram.com/<?php echo e($data->username); ?>"><?php echo e($data->username); ?></a>
                                        <span class="users-list-date"><button data-user="<?php echo e($data->username); ?>" data-id="<?php echo e($data->pk); ?>" class="btn btn-default follow">Follow</button> </span>
                                    </li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                            <!-- /.users-list -->
                        </div>

                    </div>
                    <!--/.box -->
                </div>
                </div>
            </section>
        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $('.follow').click(function () {
        var id = $(this).attr('data-id');
        var user = $(this).attr('data-user');
        $.toast("Wait .. ");
        $.ajax({
            type:'POST',
            url:'<?php echo e(url('/instagram/follow')); ?>',
            data:{
                'userId':id
            },
            success:function (data) {
                if(data=='success'){
                    $.toast("Done ! Now you are following "+user);
                }else{
                    $.toast(data);
                }
            },
            error:function (data) {
                swal('Error',"Something went wrong , Please check console message");
                console.log(data.responseText);
            }

        })
    })
</script>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>