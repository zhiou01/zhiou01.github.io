<?php $__env->startSection('title','Edit user | SocialLit'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div id="settingspage"></div>

        <div class="content-wrapper">
            <section class="content">
                <div  style="padding:10px" class="row">
                    <div  class="box no-border">
                        <div class="box-body">
                            <div class="col-md-12">

                                <div class="col-md-6">

                                    <div class="box-body">
                                        <div class="form-group">
                                            <label for="email"><i class="fa fa-envelope"></i> Email</label>
                                            <input class="form-control" id="email"
                                                   placeholder="Your Email" value="<?php echo e($email); ?>" type="email" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="name"><i class="fa fa-user"></i> Name</label>
                                            <input class="form-control" id="name"
                                                   placeholder="Your Name" value="<?php echo e($name); ?>" type="text">
                                        </div>

                                        <div class="form-group">
                                            <label for="pass"><i class="fa fa-key"></i> Password</label>
                                            <input class="form-control" value="" id="pass"
                                                   placeholder="Password" type="password">
                                        </div>

                                        

                                        <div id="plugins" class="form-group">
                                            <div class="form-group">
                                                <label>Available features</label>
                                            </div>

                                            <div class="form-group">
                                                <label>Select more Packages/features for this users</label>
                                            </div>
                                            <?php $__currentLoopData = $plugins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plugin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="box <?php if(\App\Http\Controllers\Plugins::check($plugin['name'],$id)): ?> box-success <?php endif; ?>">


                                                    <div class="box-header">

                                                        <kbd><?php echo e($plugin['name']); ?></kbd> <br>
                                                    </div>

                                                    <div class="box-body">
                                                        <?php echo $plugin['description']; ?>

                                                    </div>
                                                    <div class="box-footer">

                                                        <div class="btn-group-xs">
                                                            <button data-id="<?php echo e($plugin['name']); ?>"
                                                                    <?php if(!\App\Http\Controllers\Plugins::check($plugin['name'],$id)): ?> disabled
                                                                    <?php endif; ?> class="btn btn-danger btn-disable">Disable
                                                            </button>
                                                            <button data-id="<?php echo e($plugin['name']); ?>"
                                                                    <?php if(\App\Http\Controllers\Plugins::check($plugin['name'],$id)): ?> disabled
                                                                    <?php endif; ?> class="btn btn-primary btn-enable">Enable
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>

                                        <div class="box-footer">
                                            <button id="save" class="btn btn-block btn-success"><i
                                                        class="fa fa-save"></i>
                                                Update User
                                            </button>
                                        </div>



                                    </div><!-- /.box-body -->
                                </div>

                                <div class="col-md-6">
                                    <div class="box-body">
                                        <div class="form-group">
                                            <div class="form-group">
                                                <label>Packages</label>
                                            </div>

                                            <div class="form-group">
                                                <label>Select packages for this user</label>
                                            </div>

                                            <div class="checkbox">
                                                <label>
                                                    <input id="fb" type="checkbox"
                                                           <?php if(\App\Http\Controllers\Data::hasPackage($id,'fb')): ?> checked <?php endif; ?>>
                                                    <i class="fa fa-facebook"></i> Facebook
                                                </label>
                                            </div>


                                            <div class="checkbox">
                                                <label>
                                                    <input id="tw" type="checkbox"
                                                           <?php if(\App\Http\Controllers\Data::hasPackage($id,'tw')): ?> checked <?php endif; ?>>
                                                    <i class="fa fa-twitter"></i> Twitter
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <label>
                                                    <input id="tu" type="checkbox"
                                                           <?php if(\App\Http\Controllers\Data::hasPackage($id,'tu')): ?> checked <?php endif; ?>>
                                                    <i class="fa fa-tumblr"></i> Tumblr
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <label>
                                                    <input id="wp" type="checkbox"
                                                           <?php if(\App\Http\Controllers\Data::hasPackage($id,'wp')): ?> checked <?php endif; ?>>
                                                    <i class="fa fa-wordpress"></i> Wordpress
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <label>
                                                    <input id="ln" type="checkbox"
                                                           <?php if(\App\Http\Controllers\Data::hasPackage($id,'ln')): ?> checked <?php endif; ?>>
                                                    <i class="fa fa-linkedin"></i> Linkedin
                                                </label>
                                            </div>
                                            <div class="checkbox">
                                                <label>
                                                    <input id="in" type="checkbox"
                                                           <?php if(\App\Http\Controllers\Data::hasPackage($id,'in')): ?> checked <?php endif; ?>>
                                                    <i class="fa fa-instagram"></i> Instagram
                                                </label>
                                            </div>

                                            <div class="checkbox">
                                                <label>
                                                    <input id="pinterest" type="checkbox"
                                                           <?php if(\App\Http\Controllers\Data::hasPackage($id,'pinterest')): ?> checked <?php endif; ?>>
                                                    <i class="fa fa-pinterest"></i> Pinterest
                                                </label>
                                            </div>


                                            <div class="checkbox">
                                                <label>
                                                    <input id="fbBot" type="checkbox"
                                                           <?php if(\App\Http\Controllers\Data::hasPackage($id,'fbBot')): ?> checked <?php endif; ?>>
                                                    <i class="fa fa-comment"></i> Facebook Messenger Bot
                                                </label>
                                            </div>

                                            <div class="checkbox">
                                                <label>
                                                    <input id="slackBot" type="checkbox"
                                                           <?php if(\App\Http\Controllers\Data::hasPackage($id,'slackBot')): ?> checked <?php endif; ?>>
                                                    <i class="fa fa-slack"></i> Slack Bot
                                                </label>
                                            </div>


                                            <div class="checkbox">
                                                <label>
                                                    <input id="reddit" type="checkbox"
                                                           <?php if(\App\Http\Controllers\Data::hasPackage($id,'pack1')): ?> checked <?php endif; ?>>
                                                    <i class="fa fa-reddit"></i> Reddit
                                                </label>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>

            </section>
        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <script src="<?php echo e(url('/opt/sweetalert.min.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/opt/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        var fb = "no", tw = "no", tu = "no", wp = "no", ln = "no", ins = "no", fbBot = "no", slackBot = "no", contacts = "no", pinterest = "no", reddit = "no";
        if ($('#fb').is(':checked')) {
            fb = 'yes';
        }
        if ($('#tw').is(':checked')) {
            tw = 'yes';
        }
        if ($('#tu').is(':checked')) {
            tu = 'yes';
        }
        if ($('#wp').is(':checked')) {
            wp = 'yes';
        }
        if ($('#in').is(':checked')) {
            ins = 'yes';
        }
        if ($('#ln').is(':checked')) {
            ln = 'yes';
        }
        if ($('#fbBot').is(':checked')) {
            fbBot = 'yes';
        }
        if ($('#slackBot').is(':checked')) {
            slackBot = 'yes';
        }
        if ($('#contacts').is(':checked')) {
            contacts = "yes";
        }
        if ($('#pinterest').is(':checked')) {
            pinterest = "yes";
        }

        if ($('#reddit').is(':checked')) {
            reddit = "yes";
        }

        //        changing stuff
        $('#fb').on('change', function () {
            if (this.checked) {
                fb = 'yes';
            } else {
                fb = 'no';
            }
        });

        $('#tw').on('change', function () {
            if (this.checked) {
                tw = 'yes';
            } else {
                tw = 'no';
            }
        });

        $('#tu').on('change', function () {
            if (this.checked) {
                tu = 'yes';
            } else {
                tu = 'no';
            }
        });

        $('#ln').on('change', function () {
            if (this.checked) {
                ln = 'yes';
            } else {
                ln = 'no';
            }
        });

        $('#in').on('change', function () {
            if (this.checked) {
                ins = 'yes';
            } else {
                ins = 'no';
            }
        });

        $('#wp').on('change', function () {
            if (this.checked) {
                wp = 'yes';
            } else {
                wp = 'no';
            }
        });

        $('#fbBot').on('change', function () {
            if (this.checked) {
                fbBot = 'yes';
            } else {
                fbBot = 'no';
            }
        });

        $('#slackBot').on('change', function () {
            if (this.checked) {
                slackBot = 'yes';
            } else {
                slackBot = 'no';
            }
        });

        $('#contacts').on('change', function () {
            if (this.checked) {
                contacts = "yes";
            } else {
                contacts = "no";
            }
        });

        $('#pinterest').on('change', function () {
            if (this.checked) {
                pinterest = "yes";
            } else {
                pinterest = "no";
            }
        });

        $('#reddit').on('change', function () {
            if (this.checked) {
                reddit = "yes";
            } else {
                reddit = "no";
            }
        });


        $('#save').click(function () {

            $.ajax({
                type: 'POST',
                url: '<?php echo e(url('/user/update')); ?>',
                data: {
                    'id': '<?php echo e($id); ?>',
                    'name': $('#name').val(),
                    'email': $('#email').val(),
                    'password': $('#pass').val(),
                    'fb': fb,
                    'tw': tw,
                    'tu': tu,
                    'wp': wp,
                    'in': ins,
                    'ln': ln,
                    'pinterest': pinterest,
                    'fbBot': fbBot,
                    'slackBot': slackBot,
                    'contacts': contacts,
                    'reddit': reddit

                },
                success: function (data) {
                    if (data == 'success') {
                        swal('Success', 'User information updated', 'success');
                        location.reload();
                    }
                    else {
                        swal('Error', data, 'error');
                    }
                },
                error: function (data) {
                    swal('Error', data, 'error');
                }
            });
        });
        $('.btn-enable').click(function () {
            var pluginName = $(this).attr('data-id');
            var userId = "<?php echo e($id); ?>";
            $.ajax({
                type: 'POST',
                url: '<?php echo e(url('/plugin/active/for/user')); ?>',
                data: {
                    'pluginName': pluginName,
                    'userId': userId,
                    'action': 'enable'
                },
                success: function (data) {
                    if (data == "success") {
                        swal("Success", "Done !", "success");
                        location.reload();
                    } else {
                        swal("Error !", data, "error");
                    }
                },
                error: function (data) {
                    swal("Error !", "Something went wrong, Please check console message", "error");
                    console.log(data.responseText);
                }
            });
        });

        $('.btn-disable').click(function () {
            var pluginName = $(this).attr('data-id');
            var userId = "<?php echo e($id); ?>";
            $.ajax({
                type: 'POST',
                url: '<?php echo e(url('/plugin/active/for/user')); ?>',
                data: {
                    'pluginName': pluginName,
                    'userId': userId,
                    'action': 'disable'
                },
                success: function (data) {
                    if (data == "success") {
                        swal("Success", "Done !", "success");
                        location.reload();
                    } else {
                        swal("Error !", data, "error");
                    }
                },
                error: function (data) {
                    swal("Error !", "Something went wrong, Please check console message", "error");
                    console.log(data.responseText);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>