<?php $__env->startSection('title','Facebook'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="content-wrapper">
            <section class="content">
                <div id="facebookpage"></div>
                <div class="row">
                    <div class="col-md-4">


                        <!-- page summary start-->
                        <div class="box">
                            <div class="box-header with-border">
                                <h3 class="box-title">Facebook Pages</h3>

                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i
                                                class="fa fa-minus"></i>
                                    </button>
                                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i
                                                class="fa fa-times"></i></button>
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body no-padding">
                                <ul class="users-list clearfix">
                                    <?php $__currentLoopData = $data['accounts']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNo => $pageData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <img src="<?php echo e($pageData['picture']['data']['url']); ?>" alt="User Image">
                                            <a class="users-list-name" target="_blank"
                                               href="http://facebook.com/<?php echo e($pageData['id']); ?>"><?php echo e($pageData['name']); ?></a>
                                            <span class="users-list-date"><?php echo e($pageData['fan_count']); ?></span>
                                        </li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                                <!-- /.users-list -->
                            </div>
                            <!-- /.box-body -->

                            <!-- /.box-footer -->
                        </div>
                        <!-- page summary end -->

                        <!-- group summary start -->
                        <div class="box box-primary">
                            <div class="box-header with-border">
                                <h3 class="box-title">Facebook Groups</h3>

                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i
                                                class="fa fa-minus"></i>
                                    </button>
                                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i
                                                class="fa fa-times"></i></button>
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body" style="display: block;">
                                <ul class="products-list product-list-in-box">
                                    <!-- listing groups start -->
                                    <?php $__currentLoopData = $fbGroups['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupNo=>$group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="item">
                                            <div class="product-img">
                                                <img src="<?php echo e($group['picture']['data']['url']); ?>" alt="Product Image">
                                            </div>
                                            <div class="product-info">
                                                <a href="javascript:void(0)" class="product-title"><?php echo e($group['name']); ?>

                                                    </a>
                                                <span class="product-description">
                          Owner :<a href="http://facebook.com/<?php if(isset($group['owner']['id'])): ?> <?php echo e($group['owner']['id']); ?> <?php endif; ?>"
                                    target="_blank"><?php if(isset($group['owner']['name'])): ?> <?php echo e($group['owner']['name']); ?> <?php endif; ?></a>
                        </span>
                                            </div>
                                        </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!--list group end -->
                                    <!-- /.item -->

                                    <!-- /.item -->
                                </ul>
                            </div>
                            <!-- /.box-body -->

                            <!-- /.box-footer -->
                        </div>

                        <!-- group summary end -->


                    </div><!-- /.col -->

                    <div class="col-md-8">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">

                                
                                <?php $tabCount = 0;?>
                                <?php $__currentLoopData = $data['accounts']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNo => $pageData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li <?php if($tabCount==0): ?> class="active" <?php endif; ?>><a href="#<?php echo e($pageData['id']); ?>"
                                                                                   data-toggle="tab"><?php echo e($pageData['name']); ?></a>
                                    </li>
                                    <?php $tabCount++;?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                            <div class="tab-content">
                                <?php $tabPaneCount = 0;?>
                                
                                <?php $__currentLoopData = $data['accounts']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNo => $pageData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="<?php if($tabPaneCount == 0): ?>active <?php endif; ?> tab-pane"
                                         id="<?php echo e($pageData['id']); ?>">
                                        <!-- Post -->
                                        
                                        <?php if(isset($pageData['feed'])): ?>
                                            <?php $__currentLoopData = $pageData['feed']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contentNo => $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(isset($content['id'])): ?>
                                                    <div class="post">
                                                        <div class="user-block">
                                                            <img class="img-circle img-bordered-sm"
                                                                 src="<?php if(isset($content['from']['picture']['data']['url'] )): ?><?php echo e($content['from']['picture']['data']['url']); ?><?php endif; ?>"
                                                                 alt="user image">
                                                            <span class='username'>
                                      <a target="_blank"
                                         href="http://facebook.com/<?php if(isset($content['from']['id'])): ?><?php endif; ?><?php echo e($content['from']['id']); ?>"><?php echo e($content['from']['name']); ?></a>


                                        <div class="optimusfbcom" data-id="<?php echo e($content['id']); ?>"
                                             data-token="<?php echo e($pageData['access_token']); ?>"><a
                                                    class='pull-right btn-box-tool'><i
                                                        class='fa fa-times'></i></a></div>
                                        <div class="optimusfbedit"
                                             data-value="<?php if(isset($content['message'])): ?><?php echo e($content['message']); ?><?php else: ?> No feed found <?php endif; ?>"
                                             data-id="<?php echo e($content['id']); ?>"
                                             data-token="<?php echo e($pageData['access_token']); ?>"><a
                                                    class='pull-right btn-box-tool'><i class='fa fa-edit'></i></a></div>
                                                                <a target="_top"
                                                                   onclick="window.open('https://plus.google.com/share?url=<?php echo e($content['permalink_url']); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                                   href="https://plus.google.com/share?url=<?php echo e($content['permalink_url']); ?>"
                                                                   class='pull-right btn-box-tool'><i
                                                                            class='fa fa-google-plus'></i></a>
                                                                <a target="_top"
                                                                   onclick="window.open('https://www.linkedin.com/cws/share?url=<?php echo e($content['permalink_url']); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                                   href="https://www.linkedin.com/cws/share?url=<?php echo e($content['permalink_url']); ?>"
                                                                   class='pull-right btn-box-tool'><i
                                                                            class='fa fa-linkedin'></i></a>
                                                                <a target="_top"
                                                                   onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=<?php echo e($content['permalink_url']); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                                   href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($content['permalink_url']); ?>"
                                                                   class='pull-right btn-box-tool'><i
                                                                            class='fa fa-facebook'></i></a>
                                                                <a target="_top"
                                                                   onclick="window.open('http://www.reddit.com/submit?url=<?php echo e($content['permalink_url']); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                                   href="http://www.reddit.com/submit?url=<?php echo e($content['permalink_url']); ?>"
                                                                   class='pull-right btn-box-tool'><i
                                                                            class='fa fa-reddit'></i></a>
                                                                <a target="_top"
                                                                   onclick="window.open('http://pinterest.com/pin/create/link/?url=<?php echo e($content['permalink_url']); ?>', 'newwindow', 'width=500, height=300'); return false;"
                                                                   href="http://pinterest.com/pin/create/link/?url=<?php echo e($content['permalink_url']); ?>"
                                                                   class='pull-right btn-box-tool'><i
                                                                            class='fa fa-pinterest-p'></i></a>
                                    </span>
                                                            <span class='description'><a
                                                                        href="http://facebook.com/<?php echo e($content['id']); ?>"
                                                                        target="_blank"> <?php echo e(\App\Http\Controllers\Prappo::date($content['created_time'])); ?></a></span>
                                                        </div><!-- /.user-block -->
                                                        <p>
                                                            <!-- feed section start -->

                                                            <?php if(isset($content['message'])): ?>
                                                                <?php echo e($content['message']); ?>

                                                            <?php else: ?>
                                                                No feed found
                                                        <?php endif; ?>

                                                        <!-- feed section end -->

                                                        </p>
                                                        
                                                        <a href="<?php if(isset($content['link'])): ?>
                                                        <?php echo e($content['link']); ?>

                                                        <?php else: ?>
                                                                #
                                                                <?php endif; ?>
                                                                " target="_blank">Link</a><br>

                                                        

                                                        <?php if(isset($content['reactions'])): ?>
                                                            <?php $likes = 0;$love = 0;$haha = 0;$wow = 0;$sad = 0;$angry = 0;$totalReactions = 0; ?>
                                                            <?php $__currentLoopData = $content['reactions']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reactionNo=>$reactions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                
                                                                <?php if($reactions['type']=='LIKE'): ?>
                                                                    <?php $likes++;$totalReactions++;?>
                                                                <?php elseif($reactions['type']=='LOVE'): ?>
                                                                    <?php $love++;$totalReactions++;?>
                                                                <?php elseif($reactions['type']=='SAD'): ?>
                                                                    <?php $sad++;$totalReactions++;?>
                                                                <?php elseif($reactions['type']=='HAHA'): ?>
                                                                    <?php $haha++;$totalReactions++;?>
                                                                <?php elseif($reactions['type']=='WOW'): ?>
                                                                    <?php $wow++;$totalReactions++;?>
                                                                <?php elseif($reactions['type']=='ANGRY'): ?>
                                                                    <?php $angry++;$totalReactions++;?>
                                                                <?php endif; ?>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <?php endif; ?>
                                                        <div id="emotions" style="padding-left: 10px" class="row">
                                                            
                                                            <img src="<?php echo e(url('/images/optimus/social/likesmall.gif')); ?>">
                                                            <?php echo e($likes); ?></span>
                                                            
                                                            <img src="<?php echo e(url('/images/optimus/social/lovesmall.gif')); ?>">
                                                            <?php echo e($love); ?>

                                                            
                                                            <img src="<?php echo e(url('/images/optimus/social/hahasmall.gif')); ?>">
                                                            <?php echo e($haha); ?>

                                                            
                                                            <img src="<?php echo e(url('/images/optimus/social/wowsmall.gif')); ?>">
                                                            <?php echo e($wow); ?>

                                                            
                                                            <img src="<?php echo e(url('/images/optimus/social/sadsmall.gif')); ?>">
                                                            <?php echo e($sad); ?>

                                                            
                                                            <img src="<?php echo e(url('/images/optimus/social/angrysmall.gif')); ?>">
                                                            <?php echo e($angry); ?>


                                                            

                                                        </div>


                                                        </p>
                                                        
                                                        <?php $countComments = 0;?>
                                                        <?php if(isset($content['comments'])): ?>
                                                            <?php $__currentLoopData = $content['comments']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentNo => $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php $countComments++;?>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                        <span class="pull-right text-muted"><?php echo e($totalReactions); ?>

                                                            Reactions - <?php echo e($countComments); ?> comments</span><br><br>
                                                        <?php $countComments = 0; ?>
                                                        <?php $likes = 0;$love = 0;$haha = 0;$wow = 0;$sad = 0;$angry = 0;$totalReactions = 0; ?>

                                                        

                                                        
                                                        <?php if(isset($content['comments'])): ?>
                                                            <?php $__currentLoopData = $content['comments']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comNo => $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(isset($com['message'])): ?>
                                                                    <div style="padding-left: 20px" class="post">
                                                                        <div class="user-block">
                                                                            <img class="img-circle img-bordered-sm"
                                                                                 src="<?php if(isset($com['from']['picture']['data']['url'])): ?><?php echo e($com['from']['picture']['data']['url']); ?> <?php endif; ?>"
                                                                                 alt="user image">
                                                                            <span class='username'>
                                                          <a target="_blank"
                                                             href="http://facebook.com/<?php if(isset($com['from']['id'])): ?><?php echo e($com['from']['id']); ?><?php endif; ?>"><?php if(isset($com['from']['name'])): ?><?php echo e($com['from']['name']); ?><?php endif; ?></a>
                                                          <div class="optimusfbcom" data-id="<?php echo e($com['id']); ?>"
                                                               data-token="<?php echo e($pageData['access_token']); ?>"><a
                                                                      class='pull-right btn-box-tool'><i
                                                                          class='fa fa-times'></i></a></div>
                                                        </span>
                                                                            <span class='description'><a
                                                                                        href="http://facebook.com/<?php echo e($com['id']); ?>"
                                                                                        target="_blank"> <?php echo e(\App\Http\Controllers\Prappo::date($com['created_time'])); ?></a></span>
                                                                        </div><!-- /.user-block -->
                                                                        <p>
                                                                            <?php echo e($com['message']); ?>


                                                                        </p>
                                                                        
                                                                        <?php if(isset($com['comments'])): ?>
                                                                            <?php $__currentLoopData = $com['comments']['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subComNo => $subCom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <div style="padding-left: 30px;"
                                                                                     class="post">
                                                                                    <div class="user-block">

                                                                                        <img class="img-circle img-bordered-sm"
                                                                                             src="<?php echo e(url('/images/optimus/social/me.png')); ?>"
                                                                                             alt="user image">
                                                                                        <span class='username'>
                                                                          <a target="_blank"
                                                                             href="http://facebook.com/<?php echo e($subCom['id']); ?>"><?php if(isset($subCom['from']['name'])): ?><?php echo e($subCom['from']['name']); ?><?php endif; ?></a>
                                                                          <div class="optimusfbcom"
                                                                               data-id="<?php echo e($subCom['id']); ?>"
                                                                               data-token="<?php echo e($pageData['access_token']); ?>"><a
                                                                                      class='pull-right btn-box-tool'><i
                                                                                          class='fa fa-times'></i></a></div>
                                                                        </span>
                                                                                        <span class='description'><a
                                                                                                    href="http://facebook.com/<?php echo e($subCom['id']); ?>"
                                                                                                    target="_blank"><?php echo e(\App\Http\Controllers\Prappo::date($subCom['created_time'])); ?></a> </span>
                                                                                    </div><!-- /.user-block -->
                                                                                    <p>
                                                                                        <?php echo e($subCom['message']); ?>

                                                                                    </p>


                                                                                </div>


                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                        <?php endif; ?>

                                                                        
                                                                        <div style="padding-left: 20px"
                                                                             class="form-horizontal">
                                                                            <div class="form-group margin-bottom-none">
                                                                                <div class="col-sm-10">
                                                                                    <input class="form-control input-sm"
                                                                                           data-id="<?php echo e($com['id']); ?>"
                                                                                           data-token="<?php echo e($pageData['access_token']); ?>"
                                                                                           placeholder="Replay.. ">
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                        <br>

                                                                        

                                                                        

                                                                    </div><!-- /.post -->
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>


                                                        

                                                        

                                                        <div class="form-horizontal">
                                                            <div class="form-group margin-bottom-none">
                                                                <div class="col-sm-12">
                                                                    <input id="commentBox" class="form-control input-sm"
                                                                           data-id="<?php echo e($content['id']); ?>"
                                                                           data-token="<?php echo e($pageData['access_token']); ?>"
                                                                           placeholder="Comment">
                                                                </div>

                                                            </div>
                                                        </div>

                                                    </div><!-- /.post -->

                                                    <!-- Post -->
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            No feed found

                                        <?php endif; ?>


                                    </div><!-- /.tab-pane -->
                                <?php $tabPaneCount++;?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- /.tab-pane -->


                            </div><!-- /.tab-content -->
                        </div><!-- /.nav-tabs-custom -->
                    </div><!-- /.col -->
                </div><!-- /.row -->

            </section><!-- /.content -->

        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <script src="<?php echo e(url('/opt/sweetalert.min.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/opt/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>