<?php $__env->startSection('title','Facebook'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper" xmlns="http://www.w3.org/1999/html">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="content-wrapper">
            <section class="content">
                <div class="row">
                    <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNo=>$page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <!-- Widget: user widget style 1 -->
                            <div class="box box-widget widget-user">
                                <!-- Add the bg color to the header using any of the bg-* classes -->
                                <div class="widget-user-header bg-black" style="background: url('<?php if(isset($page['cover'])): ?><?php echo e($page['cover']['source']); ?><?php endif; ?>') center center;">
                                    <h3 class="widget-user-username"><?php echo e($page['name']); ?></h3>
                                    <h5 class="widget-user-desc"><?php echo e($page['category']); ?></h5>
                                </div>
                                <div class="widget-user-image">
                                    <img class="img-circle" src="<?php echo e($page['picture']['data']['url']); ?>" alt="User Avatar">
                                </div>
                                <div class="box-footer">
                                    <div class="row">

                                        <!-- /.col -->
                                        <div class="col-sm-4 border-right">
                                            <div class="description-block">
                                                <h5 class="description-header"><?php echo e($page['fan_count']); ?></h5>
                                                <span class="description-text">FANS</span>
                                            </div>
                                            <!-- /.description-block -->
                                        </div>
                                        <!-- /.col -->
                                        <div class="col-sm-8 border-right">
                                            <div class="description-block">
                                                <a href="<?php echo e(url('/conversations/')); ?>/<?php echo e($page['id']); ?>" class="btn btn-default"><i class="fa fa-comments"> Open conversations</i> </a>
                                            </div>
                                        </div>
                                        <!-- /.col -->
                                    </div>
                                    <!-- /.row -->
                                </div>
                            </div>
                            <!-- /.widget-user -->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>