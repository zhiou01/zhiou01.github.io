<?php $__env->startSection('title','Software Update'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div class="content-wrapper">
            <section class="content">

                <div class="row">
                    <div class="col-md-12">
                        <div class="box no-border">
                            <div class="box-header">
                                <b>Software Update</b>
                            </div>
                            <div class="box-body">
                                <div id="update_notification" style="display:none;" class="alert alert-info">
                                    <button type="button" style="margin-left: 20px" class="close" data-dismiss="alert"
                                            aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo e(\App\Http\Controllers\AdminController::softwareUpdateLog(file_get_contents(base_path().'/version.txt'))); ?>



                <div class="row">
                    <div class="col-md-12">
                        <!-- The time line -->
                        <ul class="timeline">
                            <!-- timeline time label -->
                            <li class="time-label">
                  <span class="bg-green">
                    Updates
                  </span>
                            </li>
                            <?php $__currentLoopData = \App\SoftwareUpdateLog::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <i class="fa fa-refresh bg-blue"></i>

                                    <div class="timeline-item">
                                        <span class="time"><i
                                                    class="fa fa-clock-o"></i> <?php echo e(\Carbon\Carbon::parse($log->created_at)->diffForHumans()); ?></span>

                                        <h3 class="timeline-header"><a href="#"><?php echo e($log->version); ?></a></h3>
                                        <div class="timeline-body">
                                            <p><?php echo e($log->created_at); ?></p>
                                        </div>


                                    </div>
                                </li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <li>
                                <i class="fa fa-clock-o bg-gray"></i>
                            </li>
                        </ul>
                    </div>
                    <!-- /.col -->
                </div>

            </section>
        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>