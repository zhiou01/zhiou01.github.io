<?php $__env->startSection('title','Reddit Search'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div id="settingspage"></div>

        <div class="content-wrapper">
            <section class="content">

                
                <div class="box">
                    <div class="box-body">
                        <div class="col-md-8"><input id="keyword" placeholder="Type Keyword to search ..." type="text"
                                                     class="form-control"></div>
                        <div class="col-md-4">
                            <button id="search" class="btn btn-success btn-block">
                                <i class="fa fa-search"></i> Search
                            </button>
                        </div>
                    </div>
                </div>

                    <div id="result" class="box box-body">
                    <p>No results</p>
                    </div>


                

            </section>
        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('#search').click(function () {
            $.ajax({
                url: '<?php echo e(url('/reddit/search')); ?>',
                type: 'POST',
                data: {
                    'keyword': $('#keyword').val()
                },
                success: function (data) {
                    $('#result').html(data);
                },
                error: function (data) {
                    alert("Something went wrong");
                    console.log(data.responseText);
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>