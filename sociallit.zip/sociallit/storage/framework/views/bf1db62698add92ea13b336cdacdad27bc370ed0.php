<?php $__env->startSection('title','Website Integration'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="content-wrapper">
            <section class="content">

                <div class="box box-widget widget-user">
                    <!-- Add the bg color to the header using any of the bg-* classes -->
                    <div class="widget-user-header bg-blue">
                        <h3 class="widget-user-username"><?php echo e(\App\FacebookPages::where('pageId',$pageId)->value('pageName')); ?></h3>

                    </div>
                    <div class="widget-user-image">
                        <img class="img-circle" src="https://graph.facebook.com/<?php echo e($pageId); ?>/picture" alt="User Avatar">
                    </div>

                    <div class="box-footer">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="description-block">
                                    <h5 class="description-header">Chat widget
                                        for <?php echo e(\App\FacebookPages::where('pageId',$pageId)->value('pageName')); ?></h5>
                                    <span class="description-text">See the left bottom side of this page. The widget will show like this</span>
                                </div>
                                <!-- /.description-block -->
                            </div>

                            <!-- /.row -->
                        </div>

                    </div>
                    <div class="fb-customerchat"
                         page_id="<?php echo e($pageId); ?>"

                         minimized="true">
                    </div>

                    <script>
                        window.fbAsyncInit = function () {
                            FB.init({
                                appId: '<?php echo e(\App\Http\Controllers\Data::get('fbAppId')); ?>',
                                autoLogAppEvents: true,
                                xfbml: true,
                                version: 'v2.11'
                            });
                        };

                        (function (d, s, id) {
                            var js, fjs = d.getElementsByTagName(s)[0];
                            if (d.getElementById(id)) {
                                return;
                            }
                            js = d.createElement(s);
                            js.id = id;
                            js.src = "https://connect.facebook.net/en_US/sdk.js";
                            fjs.parentNode.insertBefore(js, fjs);
                        }(document, 'script', 'facebook-jssdk'));
                    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>