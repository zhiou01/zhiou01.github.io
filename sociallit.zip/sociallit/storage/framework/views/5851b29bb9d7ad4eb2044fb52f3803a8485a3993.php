<?php $__env->startSection('title','Instagram Scraper'); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="content-wrapper">
            <section class="content">


                
                <div class="box">
                    <div class="box-header">
                        <div align="center" class="row">
                            <div class="col-md-6">
                                <input id="query" placeholder="Type here what you are looking for" class="form-control">
                            </div>
                            <div class="col-md-4">
                                <select id="type" class="form-control">

                                    <option value="tag">Feed by HashTag</option>
                                    <option value="user">User</option>
                                    

                                </select>
                            </div>

                            <div class="col-md-2">
                                <button id="search" class="btn btn-success"><i class="fa fa-search"></i> Search</button>
                            </div>
                        </div>
                    </div>
                    <div style="display: none" align="center" id="wait">
                        <img src="<?php echo e(url('/images/optimus/social/loader.gif')); ?>"><br>
                        <h3>Please wait ....</h3>
                    </div>
                    <div id="scraper" class="box-body">

                        
                    </div>
                    

                    


                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
$('#search').click(function () {
    $('#wait').show(500);
    $('#scraper').html(" ");
    $.ajax({
       type:'POST',
        url:'<?php echo e(url('/instagram/scraper')); ?>',
        data:{
            'type':$('#type').val(),
            'data':$('#query').val()
        },success:function (data) {
            $('#wait').hide(300);
            $('#scraper').html(data);

        },error:function (data) {
            $('#wait').hide(300);
            $('#scraper').html("Something went wrong . Please check the console message");
            console.log(data.responseText);
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>