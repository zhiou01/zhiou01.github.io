<ul class="timeline">
    <?php $__currentLoopData = $output; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($content != ""): ?>
            <li>
                <i class="fa fa-file-text bg-green"></i>

                <div class="timeline-item">
                    <div class="timeline-body">
                        <b><?php echo e($content); ?></b>
                    </div>
                    <div class="timeline-footer">

                    </div>
                </div>
            </li>
        <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <li>
            <i class="fa fa-clock-o bg-gray"></i>
        </li>
</ul>