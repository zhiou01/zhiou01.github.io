<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img <?php if(Auth::user()->img == ""): ?> src="<?php echo e(url('/images/admin-lte/avatar.png')); ?>"
                     <?php else: ?> src="<?php echo e(url('/uploads')); ?>/<?php echo e(Auth::user()->img); ?>" <?php endif; ?> class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e(\Auth::user()->name); ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">

            
            <?php if(Auth::user()->type == 'admin'): ?>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-user"></i>
                        <span><?php echo e(trans('sidebar.Admin Panel')); ?></span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>

                    <ul class="treeview-menu" style="display: none">
                        <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dot-circle-o"></i>
                                <span>Dashboard</span></a></li>
                        <li><a href="<?php echo e(url('/user/add')); ?>"><i class="fa fa-dot-circle-o"></i>
                                <span><?php echo e(trans('sidebar.Add User')); ?></span></a>
                        </li>
                        <li><a href="<?php echo e(url('/user/list')); ?>"><i class="fa fa-dot-circle-o"></i>
                                <span><?php echo e(trans('sidebar.Users')); ?></span></a></li>
                        <li><a href="<?php echo e(url('/admin/options')); ?>"><i class="fa fa-dot-circle-o"></i>
                                <span>Options</span></a></li>

                        <li><a href="<?php echo e(url('/software/update')); ?>"><i class="fa fa-dot-circle-o"></i>
                                <span>Software Update</span></a></li>

                        <?php echo \App\Http\Controllers\Plugins::menu("admin"); ?>


                    </ul>
                </li>

                <?php endif; ?>
                
                </a></li>
                <li><a href="<?php echo e(url('/write')); ?>"><i class="fa fa-edit"></i> <span><?php echo e(trans('sidebar.Write')); ?></span></a>
                <li><a href="<?php echo e(url('/schedule/filter/all')); ?>"><i class="fa fa-calendar"></i> <span>Schedule Posts</span></a>
                </li>
                
                

                
                <?php if(\App\Http\Controllers\Data::myPackage('contacts')): ?>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-list-ul"></i>
                            <span><?php echo e(trans('sidebar.Contacts')); ?></span>
                            <i class="fa fa-angle-left pull-right"></i>
                        </a>

                        <ul class="treeview-menu" style="display: none">

                            <li><a href="<?php echo e(url('/contact/create')); ?>"><i class="fa fa-user-plus"></i>
                                    <span><?php echo e(trans('sidebar.New Contact')); ?></span></a></li>

                            <li><a href="<?php echo e(url('/contact')); ?>"><i class="fa fa-list-alt"></i>
                                    <span><?php echo e(trans('sidebar.Contact List')); ?></span></a>
                            </li>

                        </ul>
                    </li>
                <?php endif; ?>
                

                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-comment"></i>
                        <span><?php echo e(trans('sidebar.Chat Bot')); ?></span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>

                    <ul class="treeview-menu" style="display: none">
                        <?php if(\App\Http\Controllers\Data::myPackage('fbBot')): ?>
                            <li><a href="<?php echo e(url('/fb/bot')); ?>"><i class="fa fa-facebook"></i>
                                    <span><?php echo e(trans('sidebar.FB')); ?></span></a></li>
                        <?php endif; ?>
                        <?php if(\App\Http\Controllers\Data::myPackage('slackBot')): ?>
                            <li><a href="<?php echo e(url('/slack/bot')); ?>"><i class="fa fa-slack"></i>
                                    <span><?php echo e(trans('sidebar.Slack')); ?></span></a></li>
                        <?php endif; ?>
                    </ul>
                </li>







                
                
                
                
                

                
                
                
                

                
                

                
                
                
                

                
                
                
                
                
                


                
                
                
                

                
                
                
                

                
                

                
                
                
                

                
                
                
                
                

                

                
                

                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-gear"></i>
                        <span><?php echo e(trans('sidebar.Settings')); ?></span><i class="fa fa-angle-left pull-right"></i>

                    </a>
                    <ul class="treeview-menu" style="display: none;">

                        <li><a href="<?php echo e(url('/settings')); ?>"><i class="fa fa-gear"></i>
                                <span><?php echo e(trans('sidebar.Settings')); ?></span></a></li>


                        <li><a href="<?php echo e(url('/profile')); ?>"><i class="fa fa-user"></i>
                                <span><?php echo e(trans('sidebar.Profile')); ?></span></a></li>


                    </ul>
                </li>

                <?php echo \App\Http\Controllers\Plugins::menu("all"); ?>


                
                
                
                
                

                
                
                
                
                
                
                
                
                

                
                
                
                

                
                
                
                
                

                
                



                




                <li class="header"></li>
                <li data-hint="test"><a href="#" onclick="introJs().start();"><i class="fa fa-circle-o text-yellow"></i>
                        <span>How to</span></a></li>
                <li>
                    <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i> Options</a>
                </li>
                <li class="header"></li>
                <li>
                    <a href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                        <i class="fa fa-sign-out"></i> Logout
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </li>



        </ul>
    </section>
    <!-- /.sidebar -->
</aside>

