<?php $__env->startSection('title','Auto Retweet'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div class="content-wrapper">
            <section class="content">
                <div class="row">
                    
                    <div class="col-md-12">
                        <div class="col-md-6">

                            <div class="col-md-12">
                                <input id="hashtag" placeholder="Type your #hashtag word without #" type="text"
                                       class="form-control"/>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <button id="retweet" class="btn btn-success btn-block"><i class="fa fa-retweet"></i> Retweet Now
                            </button>
                        </div>
                    </div>
                </div>
                <div class="row content">
                    <div class="col-md-12">
                        <div id="msg"></div>
                    </div>
                </div>


                

            </section>
        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $('#retweet').click(function () {
            $('#msg').html('Please wait ....');
            $.ajax({
                type: 'POST',
                url: '<?php echo e(url('/twitter/retweet/hashtag')); ?>',
                data: {

                    'hashtag': $('#hashtag').val()
                },
                success: function (data) {
//                    if (data.status == "success") {
//                        $('#msg').html(data.content);
//                    } else {
//                        $('#msg').html(data.content);
//                    }

                    $('#msg').html(data);
                },
                error: function (data) {
                    $('#msg').html('<h4 style="color:red">Something went wrong</h4>');
                }
            })
        })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>