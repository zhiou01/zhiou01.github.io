<?php
return [
    "Select your language"=>"Select your language",
    "See All Messages"=>"See All Messages",
    "See All Notifications"=>"See All Notifications",
    "Profile"=>"Profile",
    "Sign out"=>"Sign out"
];