<?php
return [
    "Dashboard"=>"Dashboard",
    "page likes"=>"page likes",
    "Loading" => "Loading",
    "followers"=>"followers",
    "company followers"=>"company followers",
    "Total Logs"=>"Total Logs",
    "Blogs"=>"Blogs",
    "Facebook"=>"Facebook",
    "Pages"=>"Pages",
    "Tumblr"=>"Tumblr",
    "Groups"=>"Groups",
    "Posted Jobs"=>"Posted Jobs",
    "Company Updates"=>"Company Updates",
    "Fllowing"=>"Fllowing",
    "Instagram"=>"Instagram",
    "Facebook page Post"=>"Facebook page Post",
    "Tumblr Posts"=>"Tumblr Posts",
    "Twitter Posts"=>"Twitter Posts",
    "Facebook Group Post"=>"Facebook Group Post",
    "All Posts"=>"All Posts"
];