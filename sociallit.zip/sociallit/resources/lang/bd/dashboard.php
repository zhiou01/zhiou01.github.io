<?php
return [
    "Dashboard" => "ড্যাশবোর্ড",

    "page likes" => "পেইজে লাইক সমূহ",
    "Loading" => "লোড হচ্ছে",
    "followers" => "followers",
    "company followers" => "company followers",
    "Total Logs" => "Total Logs",
    "Blogs" => "Blogs",
    "Facebook" => "Facebook",
    "Pages" => "Pages",
    "Tumblr" => "Tumblr",
    "Groups" => "Groups",
    "Posted Jobs" => "Posted Jobs",
    "Company Updates" => "Company Updates",
    "Fllowing" => "Fllowing",
    "Instagram" => "Instagram",
    "Facebook page Post" => "Facebook page Post",
    "Tumblr Posts" => "Tumblr Posts",
    "Twitter Posts" => "Twitter Posts"
];